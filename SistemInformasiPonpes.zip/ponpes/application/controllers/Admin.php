<?php
defined('BASEPATH') or exit('No direct script access allowed');

/**
 *
 */
class Admin extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        // security di helper dengan method is_logged_in()
        is_logged_in();

        // security jika yang masuk bukan role id 1 maka di block
        if ($this->session->userdata('role_id') != 1) {
            redirect('auth/blocked');
        }

        // load model Admin_model
        $this->load->model('Admin_model');
    }

    public function index()
    {
        $data['title'] = 'Dashboard';
        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();

        $data['jumlah_mts'] = $this->Admin_model->jumlahMts();
        $data['jumlah_ma'] = $this->Admin_model->jumlahMa();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('admin/index', $data);
        $this->load->view('templates/footer');
    }

    public function akses()
    {
        $data['title'] = 'Akses';
        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();

        // load model
        $this->load->model('Admin_model', 'user');
        // ambil data user yang sudah di join dengan data user_menu melalui model dengan method getmenu()
        $data['role'] = $this->user->getrole();

        // ambil semua data dari tabel user_role di database
        $data['role_id'] = $this->db->get('user_role')->result_array();

        $this->form_validation->set_rules('name', 'Name', 'required');
        $this->form_validation->set_rules('email', 'Email', 'required');
        $this->form_validation->set_rules('role_id', 'Role', 'required');

        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('admin/akses', $data);
            $this->load->view('templates/footer');
        } else {
            $this->Admin_model->addAkun();
            $this->session->set_flashdata(
                'message',
                '<div class="alert alert-success" role="alert">
                    Data berhasil di tambah !
                </div>'
            );
            redirect('admin/akses');
        }
    }

    public function editAkses($id)
    {
        $data['title'] = 'Edit Akses User';
        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();


        // load model dengan memberi data user
        $this->load->model('Admin_model', 'user');

        // ambil data user yang sudah di join dengan data user_menu melalui model dengan method getmenu()
        $data['role'] = $this->user->getrole();

        // ambil semua data dari tabel user_role di database
        $data['role_id'] = $this->db->get('user_role')->result_array();

        // ambil data dari Admin_model dengan method getId
        $data['idakses'] = $this->Admin_model->getId($id);

        $this->form_validation->set_rules('name', 'Name', 'required');
        $this->form_validation->set_rules('email', 'Email', 'required');
        $this->form_validation->set_rules('role_id', 'Role', 'required');

        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('admin/editAkses', $data);
            $this->load->view('templates/footer');
        } else {
            $this->Admin_model->editUserAkses();
            $this->session->set_flashdata(
                'message',
                '<div class="alert alert-success" role="alert">
                    Data berhasil di edit !
                </div>'
            );
            redirect('admin/akses');
        }
    }

    public function hapusUser($id)
    {
        $this->load->model('Admin_model');
        $this->Admin_model->hapusUser($id);

        $this->session->set_flashdata(
            'message',
            '<div class="alert alert-success" role="alert">
                Data Berhasil Di Hapus !
            </div>'
        );
        redirect('admin/akses');
    }
}
