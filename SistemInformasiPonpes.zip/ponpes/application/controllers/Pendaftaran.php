<?php
defined('BASEPATH') or exit('No direct script access allowed');
 
class Pendaftaran extends CI_Controller
{


    public function __construct()
    {
        parent::__construct();
        $this->load->model('Pendaftaran_model'); // load model Pendaftaran_model.php
         $this->load->model('User_model');
    }

    public function formMts()
    {
        $data['title'] = 'Formulir PSB Mts';
        $this->load->model('User_model');
        $data['dropdown'] = $this->User_model->dropdown_navbar();
        $data['dropdown_item'] = $this->User_model->dropdown_navbar_item();

        
        $this->load->view('templates_user/pageNavbar', $data);
        $this->load->view('user/formMts', $data);
        $this->load->view('templates_user/footer');
    }
 
    public function formMa()
    {

        $data['title'] = 'Formulir PSB MA';
        $data['dropdown'] = $this->User_model->dropdown_navbar();
        $data['dropdown_item'] = $this->User_model->dropdown_navbar_item();
      
        $this->load->view('templates_user/pageNavbar', $data);
        $this->load->view('templates_user/mini-bar', $data);
        $this->load->view('user/formMa', array('error' => ' '));
        $this->load->view('templates_user/footer');
    }

    public function tambah_mts()
    {
        $this->Pendaftaran_model->inputMts();
        $this->load->view('user/formMts', array('error' => ' '));
        $this->session->set_flashdata('message', 'Selamat, Data anda telah kami terima<br>kami akan memberi info selanjutnya melalui sms/whatsApp.</br>');
        redirect('user/mts');
    }

    public function tambah_ma()
    {
        $this->Pendaftaran_model->inputMa();
        $this->load->view('user/formMa', array('error' => ' '));
        $this->session->set_flashdata('message', 'Selamat, Data anda telah kami terima<br>kami akan memberi info selanjutnya melalui sms/whatsApp.</br>');
        redirect('user/ma');
    }
}
