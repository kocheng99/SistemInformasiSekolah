<?php
defined('BASEPATH') or exit('No direct script access allowed');
 
/**
 *
 */
class Petugas2 extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();

        is_logged_in();
        
        if ($this->session->userdata('role_id') != 3) {
            redirect('auth/blocked');
        }

        $this->load->model('Petugas2_model');
    }

    public function index()
    {
        $data['title'] = 'My Profile';
        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('petugas2/index', $data);
        $this->load->view('templates/footer');
    }

    public function edit()
    {
        $data['title'] = 'Edit Profile';
        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();

        $this->form_validation->set_rules('name', 'Full Name', 'required|trim');

        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('petugas2/edit', $data);
            $this->load->view('templates/footer');
        } else {
            $this->load->model('Akun_model');
            $this->Akun_model->edit_profile();

            $this->session->set_flashdata(
                'message',
                '<div class="alert alert-success" role="alert">
                    Profil Telah Berhasil Di Update ! 
                </div>'
            );
            redirect('petugas2');
        }
    }

    public function change_password()
    {
        $data['title'] = 'Change Password';
        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();

        $this->form_validation->set_rules('current_password', 'Current Password', 'required|trim');
        $this->form_validation->set_rules('new_password1', 'new Password', 'required|trim|min_length[3]|matches[new_password2]');
        $this->form_validation->set_rules('new_password2', 'Confirm New Password', 'required|trim|min_length[3]|matches[new_password1]');

        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('petugas2/change_password', $data);
            $this->load->view('templates/footer');
        } else {
            $current_password = $this->input->post('current_password');
            $new_password = $this->input->post('new_password1');

            if (!password_verify($current_password, $data['user']['password'])) {
                $this->session->set_flashdata(
                    'message',
                    '<div class="alert alert-danger" role="alert">
                    Password saat ini salah ! 
                </div>'
                );
                redirect('petugas2/change_password');
            } else {
                if ($current_password == $new_password) {
                    $this->session->set_flashdata(
                        'message',
                        '<div class="alert alert-danger" role="alert">
                        Password baru tidak boleh sama dengan password saat ini ! 
                    </div>'
                    );
                    redirect('petugas2/change_password');
                } else {
                    // password sudah ok
                    $password_hash = password_hash($new_password, PASSWORD_DEFAULT);

                    $this->db->set('password', $password_hash);
                    $this->db->where('email', $this->session->userdata('email'));
                    $this->db->update('user');
                    

                    $this->session->set_flashdata(
                        'message',
                        '<div class="alert alert-success" role="alert">
                        Password baru berhasil di ubah ! 
                    </div>'
                    );
                    redirect('petugas2/change_password');
                }
            }
        }
    }

    public function pendaftaran_ma()
    {
        $data['title'] = 'Pendaftaran Santri MA';
        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();

        $data['formulir']= $this->db->get('form_ma')->result_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('petugas2/pendaftaran', $data);
        $this->load->view('templates/footer');
    }

    public function downloadAkte($id = null)
    {
        if (!isset($id)) {
            show_404();
        }

        if ($this->Petugas2_model->downloadAkte($id)) {
            redirect('petugas2/pendaftaran_ma');
        }
    }

    public function downloadKk($id = null)
    {
        if (!isset($id)) {
            show_404();
        }

        if ($this->Petugas2_model->downloadKk($id)) {
            redirect('petugas2/pendaftaran_ma');
        }
    }

    public function detailForm($id)
    {
        $data['title'] = 'Detail Formulir Pendaftaran';
        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();

        $data['detail'] = $this->Petugas2_model->getIdForm($id);

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('petugas2/detailForm', $data);
        $this->load->view('templates/footer');
    }

    public function cetakForm($id)
    {
        $data['title'] = 'Detal Formulir Pendaftaran';
        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();

        $data['detail'] = $this->Petugas2_model->getIdForm($id);

        $this->load->view('petugas2/cetakForm', $data);
    }

    public function hapusForm($id)
    {
        $this->Petugas2_model->hapusForm($id);
        $this->session->set_flashdata('message', 'Data berhasil di hapus');
        redirect('petugas2/pendaftaran_ma');
    }

    public function editForm($id)
    {
        $data['title'] = 'Edit Data Form PSB';
        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();

        $data['detail'] = $this->Petugas2_model->getIdForm($id);

        $this->form_validation->set_rules('nama', 'Nama', 'required');
        $this->form_validation->set_rules('ttl', 'Ttl', 'required');
        $this->form_validation->set_rules('jenis_kelamin', 'Jenis_kelamin', 'required');
        $this->form_validation->set_rules('nisn', 'Nisn', 'required');
        $this->form_validation->set_rules('nik', 'Nik', 'required');
        $this->form_validation->set_rules('anak', 'Anak', 'required');
        $this->form_validation->set_rules('status_anak', 'Status_anak', 'required');
        $this->form_validation->set_rules('alamat', 'Alamat', 'required');
        $this->form_validation->set_rules('status_santri', 'Status_santri', 'required');
        $this->form_validation->set_rules('sekolah_asal', 'Sekolah_asal', 'required');
        $this->form_validation->set_rules('nama_sekolah', 'Nama_sekolah', 'required');
        $this->form_validation->set_rules('alamat_sekolah', 'Alamat_sekolah', 'required');
        $this->form_validation->set_rules('kk', 'Kk', 'required');
        $this->form_validation->set_rules('nama_ayah', 'Nama_ayah', 'required');
        $this->form_validation->set_rules('nik_ayah', 'Nik_ayah', 'required');
        $this->form_validation->set_rules('pekerjaan_ayah', 'Pekerjaan_ayah', 'required');
        $this->form_validation->set_rules('nama_ibu', 'Nama_ibu', 'required');
        $this->form_validation->set_rules('nik_ibu', 'Nik_ibu', 'required');
        $this->form_validation->set_rules('pekerjaan_ibu', 'Pekerjaan_ibu', 'required');
        $this->form_validation->set_rules('nomor_hp', 'Nomor_hp', 'required');

        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('petugas2/editForm', $data);
            $this->load->view('templates/footer');
        } else {
            $this->Petugas2_model->editForm();
            $this->session->set_flashdata('message', 'Data berhasil di ubah');
            redirect('petugas2/pendaftaran_ma');
        }
    }
}
