<?php
defined('BASEPATH') or exit('No direct script access allowed');

/**
 *
 */
class User extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('User_model');
    }

    public function index()
    {
        $data['title'] = 'Ponpes Modern Al-Mu’minien';
        $data['dropdown'] = $this->User_model->dropdown_navbar();
        $data['dropdown_item'] = $this->User_model->dropdown_navbar_item();

        $data['beranda'] = $this->db->get('beranda')->row_array();

        $data['first_card'] = $this->db->get_where('beranda', ['judul' => 'No. 1'])->row_array();
        $data['second_card'] = $this->db->get_where('beranda', ['judul' => 'No. 2'])->row_array();

        $data['informasi'] = $this->db->get('informasi')->result_array(); // get data informasi

        $this->load->view('templates_user/header', $data);
        $this->load->view('templates_user/homeNavbar', $data);
        $this->load->view('user/index', $data);
        $this->load->view('templates_user/footer');
    }

    public function sejarah()
    {
        $data['title'] = 'Sejarah';
        $data['dropdown'] = $this->User_model->dropdown_navbar();
        $data['dropdown_item'] = $this->User_model->dropdown_navbar_item();

        $data['konten'] = $this->db->get('sejarah')->result_array();

        $this->load->view('templates_user/pageNavbar', $data);
        $this->load->view('templates_user/mini-bar', $data);
        $this->load->view('user/sejarah2', $data);
        $this->load->view('templates_user/footer');
    }

    public function visi_misi()
    {
        $data['title'] = 'Visi - Misi';
        $data['dropdown'] = $this->User_model->dropdown_navbar();
        $data['dropdown_item'] = $this->User_model->dropdown_navbar_item();

        $this->load->view('templates_user/pageNavbar', $data);
        $this->load->view('templates_user/mini-bar', $data);
        $this->load->view('user/visi_misi', $data);
        $this->load->view('templates_user/footer');
    }

    public function santri()
    {
        $data['title'] = 'Santri';
        $data['dropdown'] = $this->User_model->dropdown_navbar();
        $data['dropdown_item'] = $this->User_model->dropdown_navbar_item();

        $data['konten'] = $this->db->get('santri')->result_array();

        $this->load->view('templates_user/pageNavbar', $data);
        $this->load->view('templates_user/mini-bar', $data);
        $this->load->view('user/santri', $data);
        $this->load->view('templates_user/footer');
    }

    public function kompetensi()
    {
        $data['title'] = 'kompetensi Guru';
        $data['dropdown'] = $this->User_model->dropdown_navbar();
        $data['dropdown_item'] = $this->User_model->dropdown_navbar_item();

        $data['konten'] = $this->db->get('kompetensi_guru')->result_array();

        $this->load->view('templates_user/pageNavbar', $data);
        $this->load->view('templates_user/mini-bar', $data);
        $this->load->view('user/kompetensi', $data);
        $this->load->view('templates_user/footer');
    }

    public function intra_kurikuler()
    {
        $data['title'] = 'Intra Kurikuler';
        $data['dropdown'] = $this->User_model->dropdown_navbar();
        $data['dropdown_item'] = $this->User_model->dropdown_navbar_item();

        $data['konten'] = $this->db->get('intra_kurikuler')->result_array();

        $this->load->view('templates_user/pageNavbar', $data);
        $this->load->view('templates_user/mini-bar', $data);
        $this->load->view('user/intrakurikuler', $data);
        $this->load->view('templates_user/footer');
    }

    public function ko_kurikuler()
    {
        $data['title'] = 'Ko-Kurikuler';
        $data['dropdown'] = $this->User_model->dropdown_navbar();
        $data['dropdown_item'] = $this->User_model->dropdown_navbar_item();

        $data['konten'] = $this->db->get('ko_kurikuler')->result_array();

        $this->load->view('templates_user/pageNavbar', $data);
        $this->load->view('templates_user/mini-bar', $data);
        $this->load->view('user/kokurikuler', $data);
        $this->load->view('templates_user/footer');
    }

    public function Kegiatan()
    {
        $data['title'] = 'Kegiatan';
        $data['dropdown'] = $this->User_model->dropdown_navbar();
        $data['dropdown_item'] = $this->User_model->dropdown_navbar_item();

        $data['konten'] = $this->db->get('Kegiatan')->result_array();

        $this->load->view('templates_user/pageNavbar', $data);
        $this->load->view('templates_user/mini-bar', $data);
        $this->load->view('user/Kegiatan', $data);
        $this->load->view('templates_user/footer');
    }

    public function sarana()
    {
        $data['title'] = 'Sarana Prasarana';
        $data['dropdown'] = $this->User_model->dropdown_navbar();
        $data['dropdown_item'] = $this->User_model->dropdown_navbar_item();

        $data['konten'] = $this->db->get('sarana')->result_array();

        $this->load->view('templates_user/pageNavbar', $data);
        $this->load->view('templates_user/mini-bar', $data);
        $this->load->view('user/sarana', $data);
        $this->load->view('templates_user/footer');
    }

    public function mts()
    {
        $data['title'] = 'Penerimaan Santri Baru MTs';
        $data['dropdown'] = $this->User_model->dropdown_navbar();
        $data['dropdown_item'] = $this->User_model->dropdown_navbar_item();

        $data['mts'] = $this->db->get('mts')->result_array();

        $this->load->view('templates_user/pageNavbar', $data);
        $this->load->view('user/mts', $data);
        $this->load->view('templates_user/footer');
    }

    public function ma()
    {
        $data['title'] = 'Penerimaan Santri Baru MA';
        $data['dropdown'] = $this->User_model->dropdown_navbar();
        $data['dropdown_item'] = $this->User_model->dropdown_navbar_item();

        $data['ma'] = $this->db->get('ma')->result_array();

        $this->load->view('templates_user/pageNavbar', $data);
        $this->load->view('user/ma', $data);
        $this->load->view('templates_user/footer');
    }

    public function galeri()
    {
        $data['title'] = 'Galeri';
        $data['dropdown'] = $this->User_model->dropdown_navbar();
        $data['dropdown_item'] = $this->User_model->dropdown_navbar_item();

        $data['galeri'] = $this->db->get('galeri')->result_array();
        // $data['galeriku'] = $this->db->get_where('galeri', ['id_galeri' => 3])->row_array();

        $this->load->view('templates_user/pageNavbar', $data);
        $this->load->view('templates_user/mini-bar', $data);
        $this->load->view('user/galeri', $data);
        $this->load->view('templates_user/footer');
    }

    public function kontak()
    {
        $data['title'] = 'Kontak';
        $data['dropdown'] = $this->User_model->dropdown_navbar();
        $data['dropdown_item'] = $this->User_model->dropdown_navbar_item();

        $data['kontak'] = $this->db->get('kontak')->result_array();

        $this->load->view('templates_user/pageNavbar', $data);
        $this->load->view('templates_user/mini-bar', $data);
        $this->load->view('user/kontak', $data);
        $this->load->view('templates_user/footer');
    }

    public function informasi()
    {
        $data['title'] = 'Informasi';
        $data['dropdown'] = $this->User_model->dropdown_navbar();
        $data['dropdown_item'] = $this->User_model->dropdown_navbar_item();

        $data['informasi'] = $this->db->get('informasi')->result_array();

        $this->load->view('templates_user/pageNavbar', $data);
        $this->load->view('templates_user/mini-bar', $data);
        $this->load->view('user/informasi', $data);
        $this->load->view('templates_user/footer');
    }

    // public function formMa()
    // {

    //     $data['title'] = 'Formulir PSB MA';
    //     $data['dropdown'] = $this->User_model->dropdown_navbar();
    //     $data['dropdown_item'] = $this->User_model->dropdown_navbar_item();

    //     $this->load->view('templates_user/pageNavbar', $data);
    //     $this->load->view('templates_user/mini-bar', $data);
    //     $this->load->view('user/formMa', $data);
    //     $this->load->view('templates_user/footer');
    // }

    // public function tambah_ma()
    // {
    //     $nama = $this->input->post('nama');
    //     $upload_foto = $this->input->post('upload_foto');

    //     $data = array (
    //             'nama' => $nama,
    //             'upload_foto' => $upload_foto
    //         );

    //     $this->User_model->input_data($data, 'daftar_ma');
    //     redirect('user/ma');
    // }
}
