<?php
defined('BASEPATH') or exit('No direct script access allowed');
   
/**
 *
 */
class Konten extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->model('Konten_model');
    }

//  BAGIAN KONTEN SEJARAH
    public function sejarah()
    {
        $data['title'] = 'Sejarah';

        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();

        $data['sejarah']= $this->db->get('sejarah')->result_array();

        $this->form_validation->set_rules('judul', 'Judul', 'required');
        $this->form_validation->set_rules('aktif', 'Aktif', 'required');
        $this->form_validation->set_rules('deskripsi', 'Deskripsi', 'required');

        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('admin/sejarah', $data);
            $this->load->view('templates/footer');
        } else {
            $this->Konten_model->tambahDeskripsi();
            $this->session->set_flashdata('message', 'Data berhasil di tambah');
            redirect('konten/sejarah');
        }
    }

    public function editSejarah($id)
    {
        $data['title'] = 'Edit Konten Sejarah';
        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();

        $data['idSejarah'] = $this->Konten_model->getIdSejarah($id);

        $this->form_validation->set_rules('judul', 'Judul', 'required');
        $this->form_validation->set_rules('aktif', 'Aktif', 'required');
        $this->form_validation->set_rules('deskripsi', 'Deskripsi', 'required');

        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('admin/editSejarah', $data);
            $this->load->view('templates/footer');
        } else {
            $this->Konten_model->editSejarah();
            $this->session->set_flashdata('message', 'Data berhasil di ubah');
            redirect('konten/sejarah');
        }
    }

    public function hapusSejarah($id)
    {
        $this->Konten_model->hapusSejarah($id);
        $this->session->set_flashdata('message', 'Data berhasil di hapus');
        redirect('konten/sejarah');
    }

    // AKHIR DARI BAGIAN KONTEN SEJARAH
// ==============================================================================================================

    // AWAL BAGIAN KONTEN VISI MISI
    public function visi_misi()
    {
        $data['title'] = 'Visi - Misi';

        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();

        $data['visimisi'] = $this->db->get('visi_misi')->result_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('admin/visi_misi', $data);
        $this->load->view('templates/footer');
    }

    public function editVisimisi($id)
    {
        $data['title'] = 'Edit Konten Visi - Misi';

        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();

        $data['idVisimisi'] = $this->Konten_model->getIdVisimisi($id);

        $this->form_validation->set_rules('judul', 'Judul', 'required');
        $this->form_validation->set_rules('deskripsi', 'Deskripsi', 'required');

        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('admin/editVisimisi', $data);
            $this->load->view('templates/footer');
        } else {
            $this->Konten_model->editVisimisi();
            $this->session->set_flashdata('message', 'Data berhasil di ubah');
            redirect('konten/visi_misi');
        }
    }

    public function hapusVisimisi($id)
    {
        $this->Konten_model->hapusVisimisi($id);
        $this->session->set_flashdata('message', 'Data berhasil di hapus');
        redirect('konten/visi_misi');
    }

    // AKHIR BAGIAN KONTEN VISI MISI
// =====================================================================================================

    // AWAL BAGIAN KONTEN SANTRI
    public function santri()
    {
        $data['title'] = 'Santri';

        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();

        $data['santri'] = $this->db->get('santri')->result_array();

        $this->form_validation->set_rules('judul', 'Judul', 'required');
        $this->form_validation->set_rules('deskripsi', 'Deskripsi', 'required');

        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('admin/santri', $data);
            $this->load->view('templates/footer');
        } else {
            $this->Konten_model->tambahSantri();
            $this->session->set_flashdata('message', 'Data berhasil di tambah');
            redirect('konten/santri');
        }
    }

    public function hapusSantri($id)
    {
        $this->Konten_model->hapusSantri($id);
        $this->session->set_flashdata('message', 'Data berhasil di hapus');
        redirect('konten/santri');
    }

    public function editSantri($id)
    {
        $data['title'] = 'Edit Konten Santri';

        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();

        $data['idSantri'] = $this->Konten_model->getIdSantri($id);
        
        $data['santri'] = $this->db->get('santri')->result_array();

        $this->form_validation->set_rules('judul', 'Judul', 'required');
        $this->form_validation->set_rules('deskripsi', 'Deskripsi', 'required');

        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('admin/editSantri', $data);
            $this->load->view('templates/footer');
        } else {
            $this->Konten_model->editSantri();
            $this->session->set_flashdata('message', 'Data berhasil di Ubah');
            redirect('konten/santri');
        }
    }
    // AKHIR BAGIAN KONTEN SANTRI
// =====================================================================================================

    // AWAL BAGIAN KONTEN KOMPETENSI GURU
    public function kompetensi()
    {
        $data['title'] = 'Kompetensi Guru';

        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();

        $data['kompetensi'] = $this->db->get('kompetensi_guru')->result_array();

        $this->form_validation->set_rules('judul', 'Judul', 'required');
        $this->form_validation->set_rules('deskripsi', 'Deskripsi', 'required');

        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('admin/kompetensi', $data);
            $this->load->view('templates/footer');
        } else {
            $this->Konten_model->tambahKompetensi();
            $this->session->set_flashdata('message', 'Data berhasil di Tambah');
            redirect('Konten/Kompetensi');
        }
    }

    public function hapusKompetensi($id)
    {
        $this->Konten_model->hapusKompetensi($id);
        $this->session->set_flashdata('message', 'Data berhasil di hapus');
        redirect('konten/kompetensi');
    }

    public function editKompetensi($id)
    {
        $data['title'] = 'Edit Konten Kompetensi Guru';

        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();

        $data['idKompetensi'] = $this->Konten_model->getIdKompetensi($id);

        $this->form_validation->set_rules('judul', 'Judul', 'required');
        $this->form_validation->set_rules('deskripsi', 'Deskripsi', 'required');

        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('admin/editKompetensi', $data);
            $this->load->view('templates/footer');
        } else {
            $this->Konten_model->editKompetensi();
            $this->session->set_flashdata('message', 'Data berhasil di Ubah');
            redirect('Konten/Kompetensi');
        }
    }
    // AKHIR BAGIAN KONTEN KOMPETENSI GURU
// =====================================================================================================

    // AWAL KONTEN INTRA KURIKULER
    public function intra_kurikuler()
    {
        $data['title'] = 'Intra-Kurikuler';

        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();

        $data['intra'] = $this->db->get('intra_kurikuler')->result_array();

        $this->form_validation->set_rules('judul', 'Judul', 'required');
        $this->form_validation->set_rules('deskripsi', 'Deskripsi', 'required');

        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('admin/intra_kurikuler', $data);
            $this->load->view('templates/footer');
        } else {
            $this->Konten_model->tambahIntra();
            $this->session->set_flashdata('message', 'Data berhasil di tambah');
            redirect('Konten/intra_kurikuler');
        }
    }

    public function hapusIntra($id)
    {
        $this->Konten_model->hapusIntra($id);
        $this->session->set_flashdata('message', 'Data berhasil di hapus');
        redirect('konten/intra_kurikuler');
    }

    public function editIntra($id)
    {
        $data['title'] = 'Intra-Kurikuler';

        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();

        $data['idIntra'] = $this->Konten_model->getIdIntra($id);

        $this->form_validation->set_rules('judul', 'Judul', 'required');
        $this->form_validation->set_rules('deskripsi', 'Deskripsi', 'required');

        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('admin/editIntra_kurikuler', $data);
            $this->load->view('templates/footer');
        } else {
            $this->Konten_model->editIntra();
            $this->session->set_flashdata('message', 'Data berhasil di edit');
            redirect('Konten/intra_kurikuler');
        }
    }
    // AKHIR BAGIAN KONTEN INTRAKURIKULER
// =====================================================================================================

    // AWAL KONTEN KO KURIKULER
    public function ko_kurikuler()
    {
        $data['title'] = 'Ko-Kurikuler';

        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();

        $data['ko'] = $this->db->get('ko_kurikuler')->result_array();

        $this->form_validation->set_rules('judul', 'Judul', 'required');
        $this->form_validation->set_rules('deskripsi', 'Deskripsi', 'required');

        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('admin/ko_kurikuler', $data);
            $this->load->view('templates/footer');
        } else {
            $this->Konten_model->tambahKo();
            $this->session->set_flashdata('message', 'Data berhasil di tambah');
            redirect('Konten/ko_kurikuler');
        }
    }

    public function hapusKo($id)
    {
        $this->Konten_model->hapusKo($id);
        $this->session->set_flashdata('message', 'Data berhasil di hapus');
        redirect('konten/ko_kurikuler');
    }

    public function editKo($id)
    {
        $data['title'] = 'Intra-Kurikuler';

        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();

        $data['idKo'] = $this->Konten_model->getIdKo($id);

        $this->form_validation->set_rules('judul', 'Judul', 'required');
        $this->form_validation->set_rules('deskripsi', 'Deskripsi', 'required');

        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('admin/editKo_kurikuler', $data);
            $this->load->view('templates/footer');
        } else {
            $this->Konten_model->editKo();
            $this->session->set_flashdata('message', 'Data berhasil di edit');
            redirect('Konten/ko_kurikuler');
        }
    }
    // AKHIR BAGIAN KONTEN KO KURIKULER
// =====================================================================================================

    // AWAL KONTEN KEGIATAN
    public function kegiatan()
    {
        $data['title'] = 'Kegiatan Sehari-hari';

        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();

        $data['kegiatan'] = $this->db->get('kegiatan')->result_array();

        $this->form_validation->set_rules('judul', 'Judul', 'required');
        $this->form_validation->set_rules('deskripsi', 'Deskripsi', 'required');

        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('admin/kegiatan', $data);
            $this->load->view('templates/footer');
        } else {
            $this->Konten_model->tambahKegiatan();
            $this->session->set_flashdata('message', 'Data berhasil di edit');
            redirect('Konten/kegiatan');
        }
    }

    public function hapusKegiatan($id)
    {
        $this->Konten_model->hapusKegiatan($id);
        $this->session->set_flashdata('message', 'Data berhasil di hapus');
        redirect('konten/kegiatan');
    }

    public function editKegiatan($id)
    {
        $data['title'] = 'Intra-Kurikuler';

        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();

        $data['idKegiatan'] = $this->Konten_model->getIdKegiatan($id);

        $this->form_validation->set_rules('judul', 'Judul', 'required');
        $this->form_validation->set_rules('deskripsi', 'Deskripsi', 'required');

        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('admin/editKegiatan', $data);
            $this->load->view('templates/footer');
        } else {
            $this->Konten_model->editKegiatan();
            $this->session->set_flashdata('message', 'Data berhasil di edit');
            redirect('Konten/kegiatan');
        }
    }
    // AKHIR BAGIAN KONTEN KEGIATAN
// =====================================================================================================

    // AWAL BAGIAN KONTEN SARANA
    public function sarana()
    {
        $data['title'] = 'Sarana';

        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();

        $data['sarana'] = $this->db->get('sarana')->result_array();

        $this->form_validation->set_rules('judul', 'Judul', 'required');
        $this->form_validation->set_rules('deskripsi', 'Deskripsi', 'required');

        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('admin/sarana', $data);
            $this->load->view('templates/footer');
        } else {
            $this->Konten_model->tambahSarana();
            $this->session->set_flashdata('message', 'Data berhasil di tambah');
            redirect('Konten/sarana');
        }
    }

    public function hapusSarana($id)
    {
        $this->Konten_model->hapusSarana($id);
        $this->session->set_flashdata('message', 'Data berhasil di hapus');
        redirect('konten/sarana');
    }

    public function editSarana($id)
    {
        $data['title'] = 'Intra-Kurikuler';

        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();

        $data['idSarana'] = $this->Konten_model->getIdSarana($id);

        $this->form_validation->set_rules('judul', 'Judul', 'required');
        $this->form_validation->set_rules('deskripsi', 'Deskripsi', 'required');

        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('admin/editSarana', $data);
            $this->load->view('templates/footer');
        } else {
            $this->Konten_model->editSarana();
            $this->session->set_flashdata('message', 'Data berhasil di edit');
            redirect('Konten/sarana');
        }
    }

    // AKHIR BAGIAN KONTEN SARANA
// =====================================================================================================
    
    // AWAL BAGIAN KONTEN MTS
    public function mts()
    {
        $data['title'] = 'INFO MTS';

        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();

        $data['mts'] = $this->db->get('mts')->result_array();

        $this->form_validation->set_rules('judul', 'Judul', 'required');
        $this->form_validation->set_rules('deskripsi', 'Deskripsi', 'required');

        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('admin/mts', $data);
            $this->load->view('templates/footer');
        } else {
            $this->Konten_model->tambahMts();
            $this->session->set_flashdata('message', 'Data berhasil di tambah');
            redirect('Konten/mts');
        }
    }

    public function hapusMts($id)
    {
        $this->Konten_model->hapusMts($id);
        $this->session->set_flashdata('message', 'Data berhasil di hapus');
        redirect('konten/mts');
    }

    public function editMts($id)
    {
        $data['title'] = 'Edit KONTEN MTS';

        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();

        $data['idMts'] = $this->Konten_model->getIdMts($id);

        $this->form_validation->set_rules('judul', 'Judul', 'required');
        $this->form_validation->set_rules('deskripsi', 'Deskripsi', 'required');

        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('admin/editMts', $data);
            $this->load->view('templates/footer');
        } else {
            $this->Konten_model->editMts();
            $this->session->set_flashdata('message', 'Data berhasil di edit');
            redirect('Konten/mts');
        }
    }
    // AKHIR BAGIAN KONTEN MTS
// =====================================================================================================
    // AWAL BAGIAN KONTEN MA
    public function ma()
    {
        $data['title'] = 'INFO MA';

        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();

        $data['ma'] = $this->db->get('ma')->result_array();

        $this->form_validation->set_rules('judul', 'Judul', 'required');
        $this->form_validation->set_rules('deskripsi', 'Deskripsi', 'required');

        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('admin/ma', $data);
            $this->load->view('templates/footer');
        } else {
            $this->Konten_model->tambahMa();
            $this->session->set_flashdata('message', 'Data berhasil di tambah');
            redirect('Konten/ma');
        }
    }

    public function hapusMa($id)
    {
        $this->Konten_model->hapusMa($id);
        $this->session->set_flashdata('message', 'Data berhasil di hapus');
        redirect('konten/ma');
    }

    public function editMa($id)
    {
        $data['title'] = 'Edit KONTEN MA';

        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();

        $data['idMa'] = $this->Konten_model->getIdMa($id);

        $this->form_validation->set_rules('judul', 'Judul', 'required');
        $this->form_validation->set_rules('deskripsi', 'Deskripsi', 'required');

        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('admin/editMa', $data);
            $this->load->view('templates/footer');
        } else {
            $this->Konten_model->editMa();
            $this->session->set_flashdata('message', 'Data berhasil di edit');
            redirect('Konten/ma');
        }
    }

    // AKHIR BAGIAN KONTEN MA
// =====================================================================================================

    // AWAL BAGIAN KONTEN GALERI
    public function galeri()
    {
        $data['title'] = 'Galeri';

        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();

        $data['galeri'] = $this->Konten_model->getAlbum();
        $data['album'] = $this->db->get('album')->result_array();

        $this->form_validation->set_rules('judul', 'Judul', 'required');
        $this->form_validation->set_rules('id_album', 'Id_album', 'required');
        $this->form_validation->set_rules('deskripsi', 'Deskripsi', 'required');

        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('admin/galeri', $data);
            $this->load->view('templates/footer');
        } else {
            $this->Konten_model->tambahGaleri();
            $this->session->set_flashdata('message', 'Data berhasil di tambah');
            redirect('konten/galeri');
        }
    }

    public function hapusGaleri($id)
    {
        $this->Konten_model->hapusGaleri($id);
        $this->session->set_flashdata('message', 'Data berhasil di hapus');
        redirect('konten/galeri');
    }

    public function editGaleri($id)
    {
        $data['title'] = 'Edit Konten Galeri';

        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();

        $data['idGaleri'] = $this->Konten_model->getIdGaleri($id);
        $data['album'] = $this->db->get('album')->result_array();
        $data['galeri'] = $this->Konten_model->getAlbum();

        $this->form_validation->set_rules('judul', 'Judul', 'required');
        $this->form_validation->set_rules('id_album', 'Id_album', 'required');
        $this->form_validation->set_rules('deskripsi', 'Deskripsi', 'required');

        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('admin/editGaleri', $data);
            $this->load->view('templates/footer');
        } else {
            $this->Konten_model->editGaleri();
            $this->session->set_flashdata('message', 'Data berhasil di edit');
            redirect('Konten/galeri');
        }
    }
    // AKHIR BAGIAN KONTEN GALERI
// =====================================================================================================

    // AWAL BAGIAN KONTEN KONTAK
    public function kontak()
    {
        $data['title'] = 'Kontak';

        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();

        $data['kontak'] = $this->db->get('kontak')->result_array();

        $this->form_validation->set_rules('judul', 'Judul', 'required');
        $this->form_validation->set_rules('deskripsi', 'Deskripsi', 'required');

        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('admin/kontak', $data);
            $this->load->view('templates/footer');
        } else {
            $this->Konten_model->tambahKontak();
            $this->session->set_flashdata('message', 'Data berhasil di tambah');
            redirect('Konten/kontak');
        }
    }

    public function hapusKontak($id)
    {
        $this->Konten_model->hapusKontak($id);
        $this->session->set_flashdata('message', 'Data berhasil di hapus');
        redirect('konten/kontak');
    }

    public function editKontak($id)
    {
        $data['title'] = 'Edit Konten Kontak';

        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();

        $data['idKontak'] = $this->Konten_model->getIdKontak($id);

        $this->form_validation->set_rules('judul', 'Judul', 'required');
        $this->form_validation->set_rules('deskripsi', 'Deskripsi', 'required');

        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('admin/editKontak', $data);
            $this->load->view('templates/footer');
        } else {
            $this->Konten_model->editKontak();
            $this->session->set_flashdata('message', 'Data berhasil di edit');
            redirect('Konten/kontak');
        }
    }
    // AKHIR BAGIAN KONTEN KONTAK
// =====================================================================================================

    // AWAL BAGIAN KONTEN INFORMASI
    public function informasi()
    {
        $data['title'] = 'informasi';

        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();

        $data['informasi'] = $this->db->get('informasi')->result_array();

        $this->form_validation->set_rules('judul', 'Judul', 'required');
        $this->form_validation->set_rules('deskripsi', 'Deskripsi', 'required');

        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('admin/informasi', $data);
            $this->load->view('templates/footer');
        } else {
            $this->Konten_model->tambahInformasi();
            $this->session->set_flashdata('message', 'Data berhasil di tambah');
            redirect('konten/informasi');
        }
    }

    public function hapusInformasi($id)
    {
        $this->Konten_model->hapusInformasi($id);
        $this->session->set_flashdata('message', 'Data berhasil di hapus');
        redirect('konten/informasi');
    }

    public function editInformasi($id)
    {
        $data['title'] = 'Edit Konten informasi';

        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();

        $data['idInformasi'] = $this->Konten_model->getIdInformasi($id);
        
        $data['informasi'] = $this->db->get('informasi')->result_array();

        $this->form_validation->set_rules('judul', 'Judul', 'required');
        $this->form_validation->set_rules('deskripsi', 'Deskripsi', 'required');

        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('admin/editInformasi', $data);
            $this->load->view('templates/footer');
        } else {
            $this->Konten_model->editInformasi();
            $this->session->set_flashdata('message', 'Data berhasil di Ubah');
            redirect('konten/informasi');
        }
    }
    // AKHIR BAGIAN KONTEN INFORMASI
// =====================================================================================================

    // K O N T E N   T  A M B A H A N

    // AWAL BAGIAN KONTEN ALBUM
    public function albumfoto()
    {
        $data['title'] = 'Album';

        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();

        $data['albumfoto'] = $this->db->get('album')->result_array();

        $this->form_validation->set_rules('nama', 'Nama', 'required');

        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('admin/albumfoto', $data);
            $this->load->view('templates/footer');
        } else {
            $this->Konten_model->addAlbum();
            $this->session->set_flashdata('message', 'Data berhasil di tambah');
            redirect('konten/albumfoto');
        }
    }

    public function hapusAlbumFoto($id)
    {
        $this->Konten_model->hapusAlbumFoto($id);
        $this->session->set_flashdata('message', 'Data berhasil di hapus');
        redirect('konten/albumfoto');
    }

    public function editAlbumFoto($id)
    {
        $data['title'] = 'Edit Album';

        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();

        $data['idAlbumFoto'] = $this->Konten_model->getIdAlbum($id);

        $this->form_validation->set_rules('nama', 'Nama', 'required');

        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('admin/editAlbumFoto', $data);
            $this->load->view('templates/footer');
        } else {
            $this->Konten_model->editAlbumFoto();
            $this->session->set_flashdata('message', 'Data berhasil di edit');
            redirect('konten/albumfoto');
        }
    }
    // AKHIR BAGIAN KONTEN ALBUM
//================================================================================================

    // AWAL BAGIAN KONTEN BERANDA
    public function beranda()
    {
        $data['title'] = 'Beranda';

        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();

        $data['beranda'] = $this->db->get('beranda')->result_array();


        $this->form_validation->set_rules('judul', 'Judul', 'required');
        $this->form_validation->set_rules('deskripsi', 'Deskripsi', 'required');

        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('admin/beranda', $data);
            $this->load->view('templates/footer');
        } else {
            $this->Konten_model->tambahBeranda();
            $this->session->set_flashdata('message', 'Data berhasil di tambah');
            redirect('konten/beranda');
        }
    }

    public function hapusBeranda($id)
    {
        $this->Konten_model->hapusBeranda($id);
        $this->session->set_flashdata('message', 'Data berhasil di hapus');
        redirect('konten/beranda');
    }

    public function editBeranda($id)
    {
        $data['title'] = 'Edit Konten Beranda';

        $data['user'] = $this->db->get_where('user', ['email' =>
        $this->session->userdata('email')])->row_array();

        $data['idBeranda'] = $this->Konten_model->getIdBeranda($id);
        
        $data['beranda'] = $this->db->get('beranda')->result_array();

        $this->form_validation->set_rules('judul', 'Judul', 'required');
        $this->form_validation->set_rules('deskripsi', 'Deskripsi', 'required');

        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('admin/editBeranda', $data);
            $this->load->view('templates/footer');
        } else {
            $this->Konten_model->editBeranda();
            $this->session->set_flashdata('message', 'Data berhasil di Ubah');
            redirect('konten/beranda');
        }
    }
    // AKHIR BAGIAN KONTEN BERANDA
// =====================================================================================================
}
