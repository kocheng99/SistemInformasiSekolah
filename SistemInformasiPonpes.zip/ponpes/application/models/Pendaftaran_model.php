<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Pendaftaran_model extends CI_Model
{
  
    public function inputMts()
    {
        $nama = $this->input->post('nama');
        $ttl = $this->input->post('ttl');
        $jenis_kelamin = $this->input->post('jenis_kelamin');
        $nisn = $this->input->post('nisn');
        $nik = $this->input->post('nik');
        $anak = $this->input->post('anak');
        $status_anak = $this->input->post('status_anak');
        $alamat = $this->input->post('alamat');
        $status_santri = $this->input->post('status_santri');
        $sekolah_asal = $this->input->post('sekolah_asal');
        $nama_sekolah = $this->input->post('nama_sekolah');
        $alamat_sekolah = $this->input->post('alamat_sekolah');
        $kk = $this->input->post('kk');
        $nama_ayah = $this->input->post('nama_ayah');
        $nik_ayah = $this->input->post('nik_ayah');
        $pekerjaan_ayah = $this->input->post('pekerjaan_ayah');
        $nama_ibu = $this->input->post('nama_ibu');
        $nik_ibu = $this->input->post('nik_ibu');
        $pekerjaan_ibu = $this->input->post('pekerjaan_ibu');
        $nomor_hp = $this->input->post('nomor_hp');

        $upload_foto = $_FILES['upload_foto']['name'];
        $upload_akte = $_FILES['upload_akte']['name'];
        $upload_kk = $_FILES['upload_kk']['name'];

        $config['upload_path'] = './assets/file_upload/mts/foto/';
        $config['allowed_types'] = 'jpg|jpeg|png';
        $config['max_size']     = '1048';

        // KONFIGURASI UNTUK APLOT FILE
        $this->load->library('upload', $config);

        if ($this->upload->do_upload('upload_foto')) {
            $image = $this->upload->data('file_name');
        } else {
            echo $this->upload->display_errors();
        }

        $config2['upload_path'] = './assets/file_upload/mts/kk/';
        $config2['allowed_types'] = 'doc|docx|pdf';
        $config2['max_size']     = '2048';
            
        $this->upload->initialize($config2);

        if ($this->upload->do_upload('upload_kk')) {
            $file_kk = $this->upload->data('file_name');
        } else {
            echo $this->upload->display_errors();
        }

        $config3['upload_path'] = './assets/file_upload/mts/akte/';
        $config3['allowed_types'] = 'doc|docx|pdf';
        $config3['max_size']     = '2048';
            
        $this->upload->initialize($config3);

        if ($this->upload->do_upload('upload_akte')) {
            $file_akte = $this->upload->data('file_name');
        } else {
            echo $this->upload->display_errors();
        }

        $data = [
            'nama' => $nama,
            'ttl' => $ttl,
            'jenis_kelamin' => $jenis_kelamin,
            'nisn' => $nisn,
            'nik' => $nik,
            'anak' => $anak,
            'status_anak' => $status_anak,
            'alamat' => $alamat,
            'status_santri' => $status_santri,
            'sekolah_asal' => $sekolah_asal,
            'nama_sekolah' => $nama_sekolah,
            'alamat_sekolah' => $alamat_sekolah,
            'kk' => $kk,
            'nama_ayah' => $nama_ayah,
            'nik_ayah' => $nik_ayah,
            'pekerjaan_ayah' => $pekerjaan_ayah,
            'nama_ibu' => $nama_ibu,
            'nik_ibu' => $nik_ibu,
            'pekerjaan_ibu' => $pekerjaan_ibu,
            'nomor_hp' => $nomor_hp,
            'upload_foto' => $image,
            'upload_kk' => $file_kk,
            'upload_akte' => $file_akte
        ];

        $this->db->insert('form_mts', $data);
    }

    public function inputMa()
    {
        
        $nama = $this->input->post('nama');
        $ttl = $this->input->post('ttl');
        $jenis_kelamin = $this->input->post('jenis_kelamin');
        $nisn = $this->input->post('nisn');
        $nik = $this->input->post('nik');
        $anak = $this->input->post('anak');
        $status_anak = $this->input->post('status_anak');
        $alamat = $this->input->post('alamat');
        $status_santri = $this->input->post('status_santri');
        $sekolah_asal = $this->input->post('sekolah_asal');
        $nama_sekolah = $this->input->post('nama_sekolah');
        $alamat_sekolah = $this->input->post('alamat_sekolah');
        $kk = $this->input->post('kk');
        $nama_ayah = $this->input->post('nama_ayah');
        $nik_ayah = $this->input->post('nik_ayah');
        $pekerjaan_ayah = $this->input->post('pekerjaan_ayah');
        $nama_ibu = $this->input->post('nama_ibu');
        $nik_ibu = $this->input->post('nik_ibu');
        $pekerjaan_ibu = $this->input->post('pekerjaan_ibu');
        $nomor_hp = $this->input->post('nomor_hp');

        $upload_foto = $_FILES['upload_foto']['name'];
        $upload_kk = $_FILES['upload_kk']['name'];
        $upload_akte = $_FILES['upload_akte']['name'];

        $config['upload_path'] = './assets/file_upload/ma/foto/';
        $config['allowed_types'] = 'jpg|jpeg|png';
        $config['max_size']     = '1048';

        $this->load->library('upload', $config);

        if ($this->upload->do_upload('upload_foto')) {
            $image = $this->upload->data('file_name');
        } else {
            echo $this->upload->display_errors();
        }

        $config2['upload_path'] = './assets/file_upload/ma/kk/';
        $config2['allowed_types'] = 'doc|docx|pdf';
        $config2['max_size']     = '2048';
            
        $this->upload->initialize($config2);

        if ($this->upload->do_upload('upload_kk')) {
            $file_kk = $this->upload->data('file_name');
        } else {
            // $error = array($this->upload->display_errors());
            echo $this->upload->display_errors();
            // $this->load->view('formMa', $error);
        }

        $config3['upload_path'] = './assets/file_upload/ma/akte/';
        $config3['allowed_types'] = 'doc|docx|pdf';
        $config3['max_size']     = '2048';
            
        $this->upload->initialize($config3);

        if ($this->upload->do_upload('upload_akte')) {
            $file_akte = $this->upload->data('file_name');
        } else {
            echo $this->upload->display_errors();
        }

        $data = array (
                'nama' => $nama,
                'ttl' => $ttl,
                'jenis_kelamin' => $jenis_kelamin,
                'nisn' => $nisn,
                'nik' => $nik,
                'anak' => $anak,
                'status_anak' => $status_anak,
                'alamat' => $alamat,
                'status_santri' => $status_santri,
                'sekolah_asal' => $sekolah_asal,
                'nama_sekolah' => $nama_sekolah,
                'alamat_sekolah' => $alamat_sekolah,
                'kk' => $kk,
                'nama_ayah' => $nama_ayah,
                'nik_ayah' => $nik_ayah,
                'pekerjaan_ayah' => $pekerjaan_ayah,
                'nama_ibu' => $nama_ibu,
                'nik_ibu' => $nik_ibu,
                'pekerjaan_ibu' => $pekerjaan_ibu,
                'nomor_hp' => $nomor_hp,
                'upload_foto' => $image,
                'upload_kk' => $file_kk,
                'upload_akte' => $file_akte
            );

        $this->db->insert('form_ma', $data);
    }
}
