<?php
defined('BASEPATH') or exit('No direct script access allowed');

/** 
 * 
 */
class Menu_model extends CI_Model
{
	public function hapusDataMenu($id)
	{
		$this->db->where('id', $id);
		$this->db->delete('user_menu');
	}

	
}