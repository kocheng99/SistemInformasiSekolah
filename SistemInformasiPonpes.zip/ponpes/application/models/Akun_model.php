<?php
defined('BASEPATH') or exit('No direct script access allowed');

/**
 *
 */
class Akun_model extends CI_Model
{


    public function edit_profile()
    {
            $name = $this->input->post('name');
            $email = $this->input->post('email');

            // cek apakah ada gambar yang di upload
            $upload_image = $_FILES['image']['name'];

        if ($upload_image) {
            $config['upload_path'] = './assets/img/profile/';
            $config['allowed_types'] = 'gif|jpg|png';
            $config['max_size']     = '2048';

            $this->load->library('upload', $config);

            if ($this->upload->do_upload('image')) {
                $old_image = $data['user']['image'];
                if ($old_image != 'default.jpg') {
                    unlink(FCPATH . 'assets/img/profile/' . $old_image);
                }

                $new_image = $this->upload->data('file_name');
                $this->db->set('image', $new_image);
            } else {
                echo $this->upload->display_errors();
            }
        }

            $this->db->set('name', $name);
            $this->db->where('email', $email);
            $this->db->update('user');
    }
}
