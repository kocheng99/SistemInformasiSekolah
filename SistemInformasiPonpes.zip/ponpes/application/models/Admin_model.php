<?php
defined('BASEPATH') or exit('No direct script access allowed');
 
/**
 *
 */
class Admin_model extends CI_Model
{
    public function getrole()
    {
        $query = "SELECT `user`.* , `user_role`.`role_id` 
                  FROM `user` JOIN `user_role`
                  ON `user`.`role_id`=`user_role`.`id` 
                ";
        return $this->db->query($query)->result_array();
    }

    public function addAkun()
    {
        $data = [
                'name' => htmlspecialchars($this->input->post('name', true)),
                'email' => htmlspecialchars($this->input->post('email', true)),
                'image' => 'default.jpg',
                'password' => password_hash('admin123', PASSWORD_DEFAULT),
                'role_id' => $this->input->post('role_id'),
                'is_active' => 1,
                'date_create' => time()
            ];

            $this->db->insert('user', $data);
    }

    public function editUserAkses()
    {
        $data = [
                'name' => $this->input->post('name'),
                'email' => $this->input->post('email'),
                'role_id' => $this->input->post('role_id')
            ];

        $this->db->where('id', $this->input->post('id'));
        $this->db->update('user', $data);
    }

    public function hapusUser($id)
    {
        $this->db->where('id', $id);
        $this->db->delete('user');
    }

    public function getId($id)
    {
        return $this->db->get_where('user', ['id' => $id])->row_array();
    }

    public function jumlahMts()
    {
        $query = $this->db->get('form_mts');
        if ($query->num_rows()>0) {
            return $query->num_rows();
        } else {
            return 0;
        }
    }

    public function jumlahMa()
    {
        $query = $this->db->get('form_ma');
        if ($query->num_rows()>0) {
            return $query->num_rows();
        } else {
            return 0;
        }
    }
}
