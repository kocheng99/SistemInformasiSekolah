<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Petugas1_model extends CI_Model
{
 

    public function downloadAkte($id)
    {
        $data = $this->db->get_where('form_mts', ['id' => $id])->row();
        force_download('assets/file_upload/mts/akte/'.$data->upload_akte, null);
    }
    public function downloadKk($id)
    {
        $data = $this->db->get_where('form_mts', ['id' => $id])->row();
        force_download('assets/file_upload/mts/kk/'.$data->upload_kk, null);
    }


    public function getIdForm($id)
    {
        return $this->db->get_where('form_mts', ['id' => $id])->row_array();
    }

    public function hapusForm($id)
    {
        $this->db->where('id', $id);
        $this->db->delete('form_mts');
    }

    public function editForm()
    {
        $data = [
            'nama' => $this->input->post('nama'),
            'ttl' => $this->input->post('ttl'),
            'jenis_kelamin' => $this->input->post('jenis_kelamin'),
            'nisn' => $this->input->post('nisn'),
            'nik' => $this->input->post('nik'),
            'anak' => $this->input->post('anak'),
            'status_anak' => $this->input->post('status_anak'),
            'alamat' => $this->input->post('alamat'),
            'status_santri' => $this->input->post('status_santri'),
            'sekolah_asal' => $this->input->post('sekolah_asal'),
            'nama_sekolah' => $this->input->post('nama_sekolah'),
            'alamat_sekolah' => $this->input->post('alamat_sekolah'),
            'kk' => $this->input->post('kk'),
            'nama_ayah' => $this->input->post('nama_ayah'),
            'nik_ayah' => $this->input->post('nik_ayah'),
            'pekerjaan_ayah' => $this->input->post('pekerjaan_ayah'),
            'nama_ibu' => $this->input->post('nama_ibu'),
            'nik_ibu' => $this->input->post('nik_ibu'),
            'pekerjaan_ibu' => $this->input->post('pekerjaan_ibu'),
            'nomor_hp' => $this->input->post('nomor_hp')
        ];

        $this->db->where('id', $this->input->post('id'));
        $this->db->update('form_mts', $data);
    }
}
