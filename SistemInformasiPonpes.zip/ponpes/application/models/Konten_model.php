<?php
defined('BASEPATH') or exit('No direct script access allowed');
  
/**
 *
 */
class Konten_model extends CI_Model
{

 // MODEL KONTEN SEJARAH
    public function tambahDeskripsi()
    {
        $data=[
            'judul' => $this->input->post('judul'),
            'dsc_sejarah' => $this->input->post('deskripsi'),
            'aktif' => $this->input->post('aktif')
        ];

        $this->db->insert('sejarah', $data);
    }

    public function editSejarah()
    {
        $data=[
            'judul' => $this->input->post('judul'),
            'dsc_sejarah' => $this->input->post('deskripsi'),
            'aktif' => $this->input->post('aktif')
        ];

        $this->db->where('id', $this->input->post('id'));
        $this->db->update('sejarah', $data);
    }

    public function hapusSejarah($id)
    {
        $this->db->where('id', $id);
        $this->db->delete('sejarah');
    }

    public function getIdSejarah($id)
    {
         return $this->db->get_where('sejarah', ['id' => $id])->row_array();
    }
    // AKHIR MODEL KONTEN SEJARAH

    // MODEL KONTEN VISI MISI
    public function editVisimisi()
    {
        $data = [
            'judul' => $this->input->post('judul'),
            'dsc_visimisi' => $this->input->post('deskripsi')
        ];

        $this->db->where('id', $this->input->post('id'));
        $this->db->update('visi_misi', $data);
    }

    public function hapusVisimisi($id)
    {
        $this->db->where('id', $id);
        $this->db->delete('visi_misi');
    }

    public function getIdVisimisi($id)
    {
        return $this->db->get_where('visi_misi', ['id' => $id])->row_array();
    }
    // Akhir Model Konten Visi Misi

    // Awal Model Konten Santri
    public function tambahSantri() // Fungsi Tambah Data
    {
        $judul = $this->input->post('judul');
        $dsc_santri = $this->input->post('deskripsi');

        $foto = $_FILES['foto']['name'];

        if ($foto) {
            $config['upload_path'] = './assets/img/foto/';
            $config['allowed_types'] = 'gif|jpg|png|jpeg';
            $config['max_size']     = '5048';

            $this->load->library('upload', $config);

            if ($this->upload->do_upload('foto')) {
                $image = $this->upload->data('file_name');
            } else {
                echo $this->upload->display_errors();
            }
        }

        $data=[
            'judul' => $judul,
            'dsc_santri' => $dsc_santri,
            'foto' => $foto
        ];

        $this->db->insert('santri', $data);
    }

    public function hapusSantri($id) // Fungsi Hapus Data
    {
        $this->db->where('id', $id);
        $this->db->delete('santri');
    }

    public function getIdSantri($id) // get atau ambil data dengan id yg di pilih dari tabel santri
    {
         return $this->db->get_where('santri', ['id' => $id])->row_array();
    }

    public function editSantri() // method untuk edit konten santri
    {
        $judul = $this->input->post('judul');
        $dsc_santri = $this->input->post('deskripsi');

        $upload_foto = $_FILES['foto']['name'];

        if ($upload_foto) {
            $config['upload_path'] = './assets/img/foto/';
            $config['allowed_types'] = 'gif|jpg|png|jpeg';
            $config['max_size']     = '5048';

            $this->load->library('upload', $config);

            if ($this->upload->do_upload('foto')) {
                $new_image = $this->upload->data('file_name');

                $this->db->set('foto', $new_image);
            } else {
                echo $this->upload->display_errors();
            }
        }

        $this->db->set('judul', $judul);
        $this->db->set('dsc_santri', $dsc_santri);
        $this->db->where('id', $this->input->post('id'));
        $this->db->update('santri');
    }

    // AWAL  MODEL KONTEN  KOMPETENSI
    public function tambahKompetensi()
    {
        $data = [
            'judul' => $this->input->post('judul'),
            'dsc_kompetensi' => $this->input->post('deskripsi'),
            'tgl_dibuat' => time()
        ];

        $this->db->insert('kompetensi_guru', $data);
    }

    public function hapusKompetensi($id)
    {
        $this->db->where('id', $id);
        $this->db->delete('kompetensi_guru');
    }

    public function getIdKompetensi($id) // get atau ambil data dengan id yg di pilih dari tabel kompetensi
    {
         return $this->db->get_where('kompetensi_guru', ['id' => $id])->row_array();
    }
    public function editKompetensi()
    {
        // $data = [
        //     'judul' => $this->input->post('judul'),
        //     'dsc_kompetensi' => $this->input->post('deskripsi'),
        //     'tgl_dibuat' => DATE('CCYY-MM-DD')
        // ];
        $judul = $this->input->post('judul');
        $deskripsi = $this->input->post('deskripsi');

        $this->db->set('judul', $judul);
        $this->db->set('dsc_kompetensi', $deskripsi);
        $this->db->update('kompetensi_guru');
    }

// =====================================================================================================

    // AWAL MDOEL INTRA KURIKULER
    public function tambahIntra()
    {
        $data = [
            'judul' => $this->input->post('judul'),
            'dsc_intrakurikuler' => $this->input->post('deskripsi'),
            'tgl_dibuat' => time()
        ];

        $this->db->insert('intra_kurikuler', $data);
    }

    public function hapusIntra($id)
    {
        $this->db->where('id', $id);
        $this->db->delete('intra_kurikuler');
    }

    public function getIdIntra($id) // get atau ambil data dengan id yg di pilih dari tabel intrkurikuler
    {
         return $this->db->get_where('intra_kurikuler', ['id' => $id])->row_array();
    }

    public function editIntra()
    {
        $data=[
            'judul' => $this->input->post('judul'),
            'dsc_intrakurikuler' => $this->input->post('deskripsi'),
            'tgl_dibuat' => time()
        ];

        $this->db->where('id', $this->input->post('id'));
        $this->db->update('intra_kurikuler', $data);
    }
    // AKHIR MODEL INTRA KURIKULER
// =====================================================================================================

    // AWAL MDOEL KO KURIKULER
    public function tambahKo()
    {
        $data = [
            'judul' => $this->input->post('judul'),
            'dsc_kokurikuler' => $this->input->post('deskripsi'),
            'tgl_dibuat' => time()
        ];

        $this->db->insert('ko_kurikuler', $data);
    }

    public function hapusKo($id)
    {
        $this->db->where('id', $id);
        $this->db->delete('ko_kurikuler');
    }

    public function getIdKo($id) // get atau ambil data dengan id yg di pilih dari tabel intrkurikuler
    {
         return $this->db->get_where('ko_kurikuler', ['id' => $id])->row_array();
    }

    public function editKo()
    {
        $data=[
            'judul' => $this->input->post('judul'),
            'dsc_kokurikuler' => $this->input->post('deskripsi'),
            'tgl_dibuat' => time()
        ];

        $this->db->where('id', $this->input->post('id'));
        $this->db->update('ko_kurikuler', $data);
    }
    // AKHIR MODEL KO KURIKULER
// =====================================================================================================

    // AWAL MODEL KEGIATAN
    public function tambahKegiatan()
    {
        $data = [
            'judul' => $this->input->post('judul'),
            'dsc_kegiatan' => $this->input->post('deskripsi'),
            'tgl_dibuat' => time()
        ];

        $this->db->insert('kegiatan', $data);
    }

    public function hapusKegiatan($id)
    {
        $this->db->where('id', $id);
        $this->db->delete('kegiatan');
    }

    public function getIdKegiatan($id) // get atau ambil data dengan id yg di pilih dari tabel intrkurikuler
    {
         return $this->db->get_where('kegiatan', ['id' => $id])->row_array();
    }

    public function editKegiatan()
    {
        $data=[
            'judul' => $this->input->post('judul'),
            'dsc_kegiatan' => $this->input->post('deskripsi'),
            'tgl_dibuat' => time()
        ];

        $this->db->where('id', $this->input->post('id'));
        $this->db->update('kegiatan', $data);
    }
    // AKHIR MODEL KEGIATAN
// =====================================================================================================

    // AWAL MODEL SARANA
    public function tambahSarana()
    {
        $data = [
            'judul' => $this->input->post('judul'),
            'dsc_sarana' => $this->input->post('deskripsi'),
            'tgl_dibuat' => time()
        ];

        $this->db->insert('sarana', $data);
    }

    public function hapusSarana($id)
    {
        $this->db->where('id', $id);
        $this->db->delete('sarana');
    }

    public function getIdSarana($id) // get atau ambil data dengan id yg di pilih dari tabel intrkurikuler
    {
         return $this->db->get_where('sarana', ['id' => $id])->row_array();
    }

    public function editSarana()
    {
        $data=[
            'judul' => $this->input->post('judul'),
            'dsc_sarana' => $this->input->post('deskripsi'),
            'tgl_dibuat' => time()
        ];

        $this->db->where('id', $this->input->post('id'));
        $this->db->update('sarana', $data);
    }
    // AKHIR MODEL SARANA
// =====================================================================================================

    // AWAL MODEL MTS
    public function tambahMts()
    {
        $data = [
            'judul' => $this->input->post('judul'),
            'dsc_mts' => $this->input->post('deskripsi'),
            'tgl_dibuat' => time()
        ];

        $this->db->insert('mts', $data);
    }

    public function hapusMts($id)
    {
        $this->db->where('id', $id);
        $this->db->delete('mts');
    }

    public function getIdMts($id) // get atau ambil data dengan id yg di pilih dari tabel intrkurikuler
    {
         return $this->db->get_where('mts', ['id' => $id])->row_array();
    }

    public function editMts()
    {
        $data=[
            'judul' => $this->input->post('judul'),
            'dsc_mts' => $this->input->post('deskripsi'),
            'tgl_dibuat' => time()
        ];

        $this->db->where('id', $this->input->post('id'));
        $this->db->update('mts', $data);
    }
    // AKHIR MODEL MTS
// =====================================================================================================

    // AWAL MODEL MA
    public function tambahMa()
    {
        $data = [
            'judul' => $this->input->post('judul'),
            'dsc_ma' => $this->input->post('deskripsi'),
            'tgl_dibuat' => time()
        ];

        $this->db->insert('ma', $data);
    }

    public function hapusMa($id)
    {
        $this->db->where('id', $id);
        $this->db->delete('ma');
    }

    public function getIdMa($id) // get atau ambil data dengan id yg di pilih dari tabel ma
    {
         return $this->db->get_where('ma', ['id' => $id])->row_array();
    }

    public function editMa()
    {
        $data=[
            'judul' => $this->input->post('judul'),
            'dsc_ma' => $this->input->post('deskripsi'),
            'tgl_dibuat' => time()
        ];

        $this->db->where('id', $this->input->post('id'));
        $this->db->update('ma', $data);
    }
    // AKHIR MODEL MA
// =====================================================================================================

    // AWAL MODEL KONTAK
    public function tambahKontak()
    {
        $data = [
            'judul' => $this->input->post('judul'),
            'dsc_kontak' => $this->input->post('deskripsi'),
            'tgl_dibuat' => time()
        ];

        $this->db->insert('kontak', $data);
    }

    public function hapusKontak($id)
    {
        $this->db->where('id', $id);
        $this->db->delete('kontak');
    }

    public function getIdKontak($id) // get atau ambil data dengan id yg di pilih dari tabel ma
    {
         return $this->db->get_where('kontak', ['id' => $id])->row_array();
    }

    public function editKontak()
    {
        $data=[
            'judul' => $this->input->post('judul'),
            'dsc_kontak' => $this->input->post('deskripsi'),
            'tgl_dibuat' => time()
        ];

        $this->db->where('id', $this->input->post('id'));
        $this->db->update('kontak', $data);
    }
    // AKHIR MODEL KONTAK
// =====================================================================================================

    // AWAL MODEL INFORMASI
    public function tambahInformasi() // Fungsi Tambah Data
    {
        $judul = $this->input->post('judul');
        $dsc_informasi = $this->input->post('deskripsi');

        $foto = $_FILES['foto']['name'];

        if ($foto) {
            $config['upload_path'] = './assets/img/foto/';
            $config['allowed_types'] = 'gif|jpg|png|jpeg';
            $config['max_size']     = '5048';

            $this->load->library('upload', $config);

            if ($this->upload->do_upload('foto')) {
                $image = $this->upload->data('file_name');
            } else {
                echo $this->upload->display_errors();
            }
        }

        $data=[
            'judul' => $judul,
            'dsc_informasi' => $dsc_informasi,
            'foto' => $foto,
            'tgl_dibuat' => time()
        ];

        $this->db->insert('informasi', $data);
    }

    public function hapusInformasi($id) // Fungsi Hapus Data
    {
        $this->db->where('id', $id);
        $this->db->delete('informasi');
    }

    public function getIdInformasi($id) // get atau ambil data dengan id yg di pilih dari tabel santri
    {
         return $this->db->get_where('informasi', ['id' => $id])->row_array();
    }

    public function editInformasi() // method untuk edit konten santri
    {
        $judul = $this->input->post('judul');
        $dsc_informasi = $this->input->post('deskripsi');

        $upload_foto = $_FILES['foto']['name'];

        if ($upload_foto) {
            $config['upload_path'] = './assets/img/foto/';
            $config['allowed_types'] = 'gif|jpg|png|jpeg';
            $config['max_size']     = '5048';

            $this->load->library('upload', $config);

            if ($this->upload->do_upload('foto')) {
                $new_image = $this->upload->data('file_name');

                $this->db->set('foto', $new_image);
            } else {
                echo $this->upload->display_errors();
            }
        }

        $this->db->set('judul', $judul);
        $this->db->set('dsc_informasi', $dsc_informasi);
        $this->db->where('id', $this->input->post('id'));
        $this->db->update('informasi');
    }
    // AKHIR MODEL INFORMASI
// =====================================================================================================

    // AWAL MODEL GALERI
    public function getAlbum()
    {
        $query = "SELECT `galeri`.* , `album`.`nama_album` 
                  FROM `galeri` JOIN `album`
                  ON `galeri`.`id_album`=`album`.`id`
                ";
        return $this->db->query($query)->result_array();
    }

    public function tambahGaleri()
    {
        $judul = $this->input->post('judul');
        $id_album = $this->input->post('id_album');
        $dsc_galeri = $this->input->post('deskripsi');

        $foto = $_FILES['foto']['name'];

        if ($foto) {
            $config['upload_path'] = './assets/img/galeri/';
            $config['allowed_types'] = 'gif|jpg|png|jpeg';
            $config['max_size']     = '5048';

            $this->load->library('upload', $config);

            if ($this->upload->do_upload('foto')) {
                $image = $this->upload->data('file_name');
            } else {
                echo $this->upload->display_errors();
            }
        }

        $data=[
            'judul' => $judul,
            'id_album' => $id_album,
            'dsc_galeri' => $dsc_galeri,
            'foto' => $foto,
            'tgl_dibuat' => time()
        ];

        $this->db->insert('galeri', $data);
    }

    public function hapusGaleri($id)
    {
        $this->db->where('id_galeri', $id);
        $this->db->delete('galeri');
    }

    public function getIdGaleri($id) // get atau ambil data dengan id yg di pilih dari tabel ma
    {
         return $this->db->get_where('galeri', ['id_galeri' => $id])->row_array();
    }

    public function editGaleri() // method untuk edit konten santri
    {
        $judul = $this->input->post('judul');
        $id_album = $this->input->post('id_album');
        $dsc_galeri = $this->input->post('deskripsi');

        $upload_foto = $_FILES['foto']['name'];

        if ($upload_foto) {
            $config['upload_path'] = './assets/img/galeri/';
            $config['allowed_types'] = 'gif|jpg|png|jpeg';
            $config['max_size']     = '5048';

            $this->load->library('upload', $config);

            if ($this->upload->do_upload('foto')) {
                $new_image = $this->upload->data('file_name');

                $this->db->set('foto', $new_image);
            } else {
                echo $this->upload->display_errors();
            }
        }

        $this->db->set('judul', $judul);
        $this->db->set('id_album', $id_album);
        $this->db->set('dsc_galeri', $dsc_galeri);
        $this->db->where('id_galeri', $this->input->post('id'));
        $this->db->update('galeri');
    }
    // AKHIR MODEL GALERI
// =====================================================================================================

    // AWAL MODEL ALBUM
    public function addAlbum()
    {
        $data = [
            'nama_album' => $this->input->post('nama'),
            'tgl_dibuat' => time()
        ];

        $this->db->insert('album', $data);
    }

    public function hapusAlbumFoto($id)
    {
        $this->db->where('id', $id);
        $this->db->delete('album');
    }

    public function getIdAlbum($id) // get atau ambil data dengan id yg di pilih dari tabel ma
    {
         return $this->db->get_where('album', ['id' => $id])->row_array();
    }

    public function editAlbumFoto()
    {
        $data = [
            'nama_album' => $this->input->post('nama'),
            'tgl_dibuat' => time()
        ];
        $this->db->where('id', $this->input->post('id'));
        $this->db->update('album', $data);
    }
    // AKHIR MODEL ALBUM
// =====================================================================================================

    // AWAL MODEL BERANDA
    public function tambahBeranda() // Fungsi Tambah Data
    {
        $judul = $this->input->post('judul');
        $dsc_beranda = $this->input->post('deskripsi');

        $foto = $_FILES['foto']['name'];

        if ($foto) {
            $config['upload_path'] = './assets/img/foto/';
            $config['allowed_types'] = 'gif|jpg|png|jpeg';
            $config['max_size']     = '5048';

            $this->load->library('upload', $config);

            if ($this->upload->do_upload('foto')) {
                $image = $this->upload->data('file_name');
            } else {
                echo $this->upload->display_errors();
            }
        }

        $data=[
            'judul' => $judul,
            'dsc_beranda' => $dsc_beranda,
            'foto' => $foto,
            'tgl_dibuat' => time()
        ];

        $this->db->insert('beranda', $data);
    }

    public function hapusBeranda($id) // Fungsi Hapus Data
    {
        $this->db->where('id', $id);
        $this->db->delete('beranda');
    }

    public function getIdBeranda($id) // get atau ambil data dengan id yg di pilih dari tabel santri
    {
         return $this->db->get_where('beranda', ['id' => $id])->row_array();
    }

    public function editBeranda() // method untuk edit konten santri
    {
        $judul = $this->input->post('judul');
        $dsc_beranda = $this->input->post('deskripsi');

        $upload_foto = $_FILES['foto']['name'];

        if ($upload_foto) {
            $config['upload_path'] = './assets/img/foto/';
            $config['allowed_types'] = 'gif|jpg|png|jpeg';
            $config['max_size']     = '5048';

            $this->load->library('upload', $config);

            if ($this->upload->do_upload('foto')) {
                $new_image = $this->upload->data('file_name');

                $this->db->set('foto', $new_image);
            } else {
                echo $this->upload->display_errors();
            }
        }

        $this->db->set('judul', $judul);
        $this->db->set('dsc_beranda', $dsc_beranda);
        $this->db->where('id', $this->input->post('id'));
        $this->db->update('beranda');
    }
    // AKHIR MODEL BERANDA
}
