<?php
defined('BASEPATH') or exit('No direct script access allowed');

/**
 *
 */
class User_model extends CI_Model
{
    public function dropdown_navbar()
    {
        $this->db->select('*, navigasi_bar.id as navigasi_bar_id, sub_navbar.navbar_id as sub_navbar_id');
        $this->db->from('navigasi_bar');
        $this->db->join('sub_navbar', 'navigasi_bar.id = sub_navbar.navbar_id', 'left');
        $this->db->group_by('navbar');
        $this->db->order_by('navigasi_bar_id');
        $query = $this->db->get();
        return $query->result_array();
    }

    // fungsi untuk mengambil sub navbar
    public function dropdown_navbar_item()
    {
        $this->db->select('*');
        $this->db->from('sub_navbar');

        $query = $this->db->get();
        return $query->result_array();
    }

    // function input_data($data, $table)
    // {
    //     $this->db->insert($table, $data);
    // }
}
