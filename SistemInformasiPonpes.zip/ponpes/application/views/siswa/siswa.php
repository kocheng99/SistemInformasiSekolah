<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>

    <div class="card shadow p-3">
        <div class="row">
            <div class="col-6 text-center">
                <img style="width: 25rem;" src="<?= base_url('assets/img/undraw_welcome_3gvl.svg') ?>" alt="">
            </div>
            <div class="col-6">
                <h3 class="text-center">Selamat Datang <b><?= $user['name'] ?></b> !</h3>
                <div class="card shadow p-3 mt-5 bg-info">
                    <p class="text-white">Saat ini kamu sudah berhasil membuat akun, selanjutnya kamu
                        dapat mengikuti langkah-langkah untuk melakukan pendaftaran. <br><br>
                        silahkan gunakan menu yang terdapat di sidebar !
                    </p>
                </div>

            </div>
        </div>
    </div>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->