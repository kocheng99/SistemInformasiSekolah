<!-- Begin Page Content -->
<div class="container-fluid">
 
    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>

    <div class="row">
        <div class="col-lg-12">
            <!-- flashdata untuk message -->
            <div class="flash-data" data-flashdata="<?= $this->session->flashdata('message');?>"></div>
            <div class="card shadow p-3">
                
                <table class="table table-hover" id="table1">

                    <thead>                     
                        <tr>
                            <th scope="col">No</th>
                            <th scope="col">Nama</th>
                            <th scope="col">nisn</th>
                            <th scope="col">nik</th>
                            <th scope="col">nomor hp</th>
                            <th scope="col">Akte</th>
                            <th scope="col">KK</th>
                            <th scope="col">Tgl Daftar</th>
                            <!-- <th scope="col">foto</th> -->
                            <th scope="col">Aksi</th>
                        </tr> 
                    </thead>
                    <tbody>
                        <?php $i = 1; ?>
                        <?php foreach ($formulir as $fo) : ?>
                            <tr>
                                <th scope="row"><?= $i; ?></th>
                                <td><?= $fo['nama'] ?></td>
                                <td><?= $fo['nisn'] ?></td>
                                <td><?= $fo['nik'] ?></td>
                                <td><?= $fo['nomor_hp'] ?></td>
                                <td><a href="<?= base_url('petugas2/downloadAkte'); ?>/<?= $fo['id']; ?>"><i class="fas fa-file-download"></i>&nbsp;<small>download</small></a></td>
                                <td><a href="<?= base_url('petugas2/downloadKk'); ?>/<?= $fo['id']; ?>"><i class="fas fa-file-download"></i>&nbsp;<small>download</small></a></td>                              
                                <td><?= date('d-m-Y', strtotime($fo['tgl_dibuat'])); ?></td>
                                <!-- untuk yang nampilin foto di table di coment sementara -->
                                <!-- <td><img width="50px" src="<?= base_url('assets/file_upload/mts/foto/') . $fo['upload_foto']; ?>"></td> -->
                                <!-- untuk yang nampilin foto di table di coment sementara -->
                                <td>
                                    <!-- detail -->
                                    <a href="<?= base_url('petugas2/detailForm'); ?>/<?= $fo['id']; ?>"><button class="btn btn-outline-success btn-sm" data-toggle="tooltip" data-placement="top" title="detail"><i class="fas fa-search-plus"></i></button></a>
                                    <!-- edit -->
                                    <a href="<?= base_url('petugas2/editForm'); ?>/<?= $fo['id']; ?>"><button class="btn btn-outline-primary btn-sm" data-toggle="tooltip" data-placement="top" title="edit"><i class="fas fa-edit"></i></button></a>
                                    <!-- hapus -->
                                    <a href="<?= base_url('petugas2/hapusForm'); ?>/<?= $fo['id']; ?>" type="button" class="tombol-hapus btn btn-outline-danger btn-sm" data-toggle="tooltip" data-placement="top" title="edit"><i class="fas fa-trash-alt"></i></a>
                                    <!-- cetak <i class="fas fa-trash-alt"></i>-->
                                    <a href="<?= base_url('petugas2/cetakForm'); ?>/<?= $fo['id']; ?>"><button class="btn btn-outline-warning btn-sm" data-toggle="tooltip" data-placement="top" title="cetak"><i class="fas fa-print"></i></button></a>
                                </td>
                            </tr>
                            <?php $i++; ?>
                        <?php endforeach; ?>
                    </tbody>
                </table>

            </div>
        </div>
    </div>
    
</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content --> 
