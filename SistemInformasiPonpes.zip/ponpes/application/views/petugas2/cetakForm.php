<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>cetak formulir</title>

    <style type="text/css">
        body{
            margin: 10px 60px;
        }
        table{
            border-collapse: collapse;
        }
        td{
            padding: 10px;
        }
        .tbisi{
            margin-top: 20px;
        }
    </style>

</head>
<body onload="window.print()">
    <table width="100%" border="1">
        <tr>
            <td align="center">
                FORMULIR PENERIMAAN SANTRI BARU
            </td>
        </tr>
    </table>
    <table class="tbisi">
        <tr>
            <td>Nama</td>
            <td>:</td>
            <td><?= $detail['nama']?></td>
        </tr>
        <tr>
            <td>Tempat, Tanggal lahir</td>
            <td>:</td>
            <td><?= $detail['ttl']?></td>
        </tr>
        <tr>
            <td>Kenis kelamin</td>
            <td>:</td>
            <td><?= $detail['jenis_kelamin']?></td>
        </tr>
        <tr>
            <td>NISN</td>
            <td>:</td>
            <td><?= $detail['nisn']?></td>
        </tr>
        <tr>
            <td>NIK</td>
            <td>:</td>
            <td><?= $detail['nik']?></td>
        </tr>
        <tr>
            <td>Anak ke-</td>
            <td>:</td>
            <td><?= $detail['anak']?></td>
        </tr>
        <tr>
            <td>Status anak</td>
            <td>:</td>
            <td><?= $detail['status_anak']?></td>
        </tr>
        <tr>
            <td>Alamat</td>
            <td>:</td>
            <td><?= $detail['alamat']?></td>
        </tr>
        <tr>
            <td>Status santri</td>
            <td>:</td>
            <td><?= $detail['status_santri']?></td>
        </tr>
        <tr>
            <td>Asal sekolah</td>
            <td>:</td>
            <td><?= $detail['sekolah_asal']?></td>
        </tr>
        <tr>
            <td>Nama sekolah</td>
            <td>:</td>
            <td><?= $detail['nama_sekolah']?></td>
        </tr>
        <tr>
            <td>Alamat sekolah</td>
            <td>:</td>
            <td><?= $detail['alamat_sekolah']?></td>
        </tr>
        <tr>
            <td>Nomor KK</td>
            <td>:</td>
            <td><?= $detail['kk']?></td>
        </tr>
        <tr>
            <td>Nama ayah</td>
            <td>:</td>
            <td><?= $detail['nama_ayah']?></td>
        </tr>
        <tr>
            <td>NIK ayah</td>
            <td>:</td>
            <td><?= $detail['nik_ayah']?></td>
        </tr>
        <tr>
            <td>Pekerjaan ayah</td>
            <td>:</td>
            <td><?= $detail['pekerjaan_ayah']?></td>
        </tr>
        <tr>
            <td>Nama ibu</td>
            <td>:</td>
            <td><?= $detail['nama_ibu']?></td>
        </tr>
        <tr>
            <td>NIK ibu</td>
            <td>:</td>
            <td><?= $detail['nik_ibu']?></td>
        </tr>
        <tr>
            <td>Pekerjaan ibu</td>
            <td>:</td>
            <td><?= $detail['pekerjaan_ibu']?></td>
        </tr>
        <tr>
            <td>Nomor HP/Whatsapp</td>
            <td>:</td>
            <td><?= $detail['nomor_hp']?></td>
        </tr>
        <tr>
            <td>Foto</td>
            <td>:</td>
            <td><img width="100px" src="<?= base_url('assets/file_upload/mts/foto/') . $detail['upload_foto']; ?>"></td>
        </tr>
        <tr>
            <td>Waktu daftar</td>
            <td>:</td>
            <td><?= $detail['tgl_dibuat']?></td>
        </tr>
    </table>
    
</body>
</html>