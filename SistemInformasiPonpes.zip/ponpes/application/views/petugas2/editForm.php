<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>
    <div class="row">
        <div class="col-sm-2">
            <a href="<?= base_url('petugas2/pendaftaran_ma');?>">
                <button class="btn btn-outline-primary mb-4"><i class="fas fa-chevron-circle-left">&nbsp;</i>KEMBALI</button>
            </a>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-10">
            <!-- flashdata untuk message -->
            <div class="flash-data" data-flashdata="<?= $this->session->flashdata('message');?>"></div>
            <div class="card shadow p-3">
                
                <form action="" method="post"> 
                    <input type="hidden" name="id" value="<?= $detail['id']; ?>">

                    <div class="form-group row">
                        <label class="col-sm-2 col-form-label" for="nama">Nama</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="nama" name="nama" value="<?= $detail['nama'];?>">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-2 col-form-label" for="ttl">Tempat, Tanggal Lahir</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="ttl" name="ttl" value="<?= $detail['ttl'];?>">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-2 col-form-label" for="jenis_kelamin">Jenis kelamin</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="jenis_kelamin" name="jenis_kelamin" value="<?= $detail['jenis_kelamin'];?>">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-2 col-form-label" for="nisn">NISN</label>
                        <div class="col-sm-10">
                            <input type="number" class="form-control" id="nisn" name="nisn" value="<?= $detail['nisn'];?>">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-2 col-form-label" for="nik">NIK</label>
                        <div class="col-sm-10">
                            <input type="number" class="form-control" id="nik" name="nik" value="<?= $detail['nik'];?>">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-2 col-form-label" for="anak">Anak ke-</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="anak" name="anak" value="<?= $detail['anak'];?>">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-2 col-form-label" for="status_anak">Status anak</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="status_anak" name="status_anak" value="<?= $detail['status_anak'];?>">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-2 col-form-label" for="alamat">Alamat</label>
                        <div class="col-sm-10">
                            <textarea class="form-control" id="alamat" name="alamat"><?= $detail['alamat'];?></textarea>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-2 col-form-label" for="status_santri">Status santri</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="status_santri" name="status_santri" value="<?= $detail['status_santri'];?>">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-2 col-form-label" for="sekolah_asal">Sekolah asal</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="sekolah_asal" name="sekolah_asal" value="<?= $detail['sekolah_asal'];?>">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-2 col-form-label" for="nama_sekolah">Nama sekolah</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="nama_sekolah" name="nama_sekolah" value="<?= $detail['nama_sekolah'];?>">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-2 col-form-label" for="alamat_sekolah">Alamat sekolah</label>
                        <div class="col-sm-10">
                            <textarea class="form-control" id="alamat_sekolah" name="alamat_sekolah"><?= $detail['alamat_sekolah'];?></textarea>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-2 col-form-label" for="kk">Nomor KK</label>
                        <div class="col-sm-10">
                            <input type="number" class="form-control" id="kk" name="kk" value="<?= $detail['kk'];?>">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-2 col-form-label" for="nama_ayah">Nama ayah</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="nama_ayah" name="nama_ayah" value="<?= $detail['nama_ayah'];?>">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-2 col-form-label" for="nik_ayah">NIK ayah</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="nik_ayah" name="nik_ayah" value="<?= $detail['nik_ayah'];?>">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-2 col-form-label" for="pekerjaan_ayah">Pekerjaan ayah</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="pekerjaan_ayah" name="pekerjaan_ayah" value="<?= $detail['pekerjaan_ayah'];?>">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-2 col-form-label" for="nama_ibu">Nama ibu</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="nama_ibu" name="nama_ibu" value="<?= $detail['nama_ibu'];?>">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-2 col-form-label" for="nik_ibu">NIK ibu</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="nik_ibu" name="nik_ibu" value="<?= $detail['nik_ibu'];?>">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-2 col-form-label" for="pekerjaan_ibu">Pekerjaan ibu</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="pekerjaan_ibu" name="pekerjaan_ibu" value="<?= $detail['pekerjaan_ibu'];?>">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label class="col-sm-2 col-form-label" for="nomor_hp">Nomor hp</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="nomor_hp" name="nomor_hp" value="<?= $detail['nomor_hp'];?>">
                        </div>
                    </div>

                    <div class="form-group row justify-content-end pt-3">
                        <div class="col-sm-10">
                            <button type="submit" class="btn btn-primary">Simpan</button>
                        </div>
                    </div>
                   
                    <!-- <button type="submit" class="mt-4 btn btn-primary">Tambah</button> -->
                </form>

            </div>
        </div>
    </div>
    
</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content --> 
