<!-- Begin Page Content --> 
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="ml-2 h3 mb-4 text-gray-800"><?= $title; ?></h1>
    
    <div class="row">
        <div class="col-lg-6">
                
            <div class="card shadow p-3">
                <form action="" method="post"> 
                    <input type="hidden" name="id" value="<?= $idakses['id']; ?>">

                    <div class="form-group">
                        <label class="ml-2" for="formGroupExampleInput">Nama</label>
                        <input type="text" class="form-control" id="name" name="name" value="<?= $idakses['name'];?>" required>
                    </div>
                    <div class="form-group">
                        <label class="ml-2" for="formGroupExampleInput">Email</label>
                        <input type="text" class="form-control" id="email" name="email" value="<?= $idakses['email']; ?>" required>
                    </div>
                    <div class="form-group">
                        <label class="ml-2" for="formGroupExampleInput">Job</label>
                        <select name="role_id" id="role_id" class="form-control" required>
                            <option value="">Pilih Job</option>

                            <?php foreach ($role_id as $r) : ?>
                                <option value="<?= $r['id'] ?>"><?= $r['role_id'] ?></option>
                            <?php endforeach; ?>

                        </select>
                    </div>
                   
                    <button type="submit" class="mt-4 btn btn-primary">Simpan</button>
                </form>
            </div>

        </div>
    </div>  


</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->
