 <!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>

    <div class="row">

        <div class="col-lg-12">
            
            <!-- flashdata untuk message -->
            <div class="flash-data" data-flashdata="<?= $this->session->flashdata('message');?>"></div>

           <div class="card shadow p-3">
            <table class="table table-hover">

                    <thead class="text-center">                     
                        <tr>
                            <th scope="col">No</th>
                            <th scope="col">Judul</th>
                            <th scope="col">Deskripsi</th>
                            <th scope="col">Aksi</th>
                        </tr> 
                    </thead>
                    <tbody>
                        <?php $i = 1; ?>
                        <?php foreach ($visimisi as $vm) : ?>
                            <tr>
                                <th scope="row"><?= $i; ?></th>
                                <td><?= $vm['judul'] ?></td>
                                <td><?= $vm['dsc_visimisi'] ?></td>
                                <td>
                                    <a href="<?= base_url('konten/editVisimisi'); ?>/<?= $vm['id']; ?>" type="button" class="btn btn-outline-primary btn-sm">Edit</a>
                                    <a href="<?= base_url('konten/hapusVisimisi'); ?>/<?= $vm['id']; ?>" type="button" class="tombol-hapus btn btn-outline-danger btn-sm mt-2">Hapus</a>
                                </td>
                            </tr>
                            <?php $i++; ?>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
 
</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->
