<!-- Begin Page Content -->
<div class="container-fluid">
 
    <!-- Page Heading -->
    <h1 class="ml-2 h3 mb-4 text-gray-800"><?= $title; ?></h1>
    
    <div class="row">
        <div class="col-lg-12">
                
            <div class="card shadow p-3">
                <form action="" method="post"> 
                    <input type="hidden" name="id" value="<?= $idKompetensi['id']; ?>">

                    <div class="form-group row">
                        <label class="col-sm-2 col-form-label" for="formGroupExampleInput">Judul</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="judul" name="judul" value="<?= $idKompetensi['judul'];?>">
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="deskripsi" class="col-sm-2 col-form-label">Deskripsi</label>
                        <div class="col-sm-10">
                            <textarea class="form-control" id="editor" name="deskripsi" rows="8"><?= $idKompetensi['dsc_kompetensi']; ?></textarea>
                        </div>
                    </div>

                    <div class="form-group row justify-content-end pt-3">
                        <div class="col-sm-10">
                            <button type="submit" class="btn btn-primary">Simpan</button>
                        </div>
                    </div>
                   
                    <!-- <button type="submit" class="mt-4 btn btn-primary">Tambah</button> -->
                </form>
            </div>

        </div>
    </div>  


</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->
