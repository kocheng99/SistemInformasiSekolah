<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading --> 
    <h1 class="ml-2 h3 mb-4 text-gray-800"><?= $title; ?></h1>
       
    <div class="row">
        <div class="col-lg-10">
            
            <!-- flashdata untuk message -->
            <?= $this->session->flashdata('message');  ?>
          <a href="#" class="btn btn-primary mb-4" data-toggle="modal" data-target=".addakun">Tambah Akun</a>
          <a href="#" class="btn btn-success mb-4" data-toggle="modal" data-target=".help">Help</a>
           <div class="card shadow p-3">
            <table class="table table-hover">
                    <thead>
                        <tr>
                            <th scope="col">No.</th> 
                            <th scope="col">Nama</th>
                            <th scope="col">Email</th>
                            <th scope="col">Job</th>
                            <th scope="col">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i = 1; ?>
                        <?php foreach ($role as $r) : ?>
                            <tr>
                                <th scope="row"><?= $i; ?></th>
                                <td><?= $r['name'] ?></td>
                                <td><?= $r['email'] ?></td>
                                <td><?= $r['role_id'] ?></td>
                                <td>
                                    <a href="<?= base_url('admin/editAkses'); ?>/<?= $r['id']; ?>" class="badge badge-success">Edit</a>
                                    <a href="<?= base_url('admin/hapusUser'); ?>/<?= $r['id']; ?>" class="badge badge-danger" onclick="
                                    return confirm('anda yakin ingin menghapus <?= $r['name']?> ?');">Delete</a>
                                </td>
                            </tr>
                            <?php $i++; ?>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->

<!-- MODAL TAMBAH AKUN-->

<div class="modal fade addakun" tabindex="-1" role="dialog" aria-labelledby="addakunTitle" aria-hidden="true">
  <div class="modal-dialog modal-xs" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="addakunTitle">Tambah Akun Baru</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="<?= base_url('admin/akses')?>" method="post">
        <div class="modal-body">
      
          <div class="form-group">
            <label for="name">Nama</label>
               <input type="text" class="form-control" id="name" name="name" required>
          </div>
          <div class="form-group">
            <label for="email">Email</label>
               <input type="text" class="form-control" id="email" name="email" required>
          </div>
          <div class="form-group">
            <label for="password">Password</label> <br>
            <small>*password default otomatis</small>
               <input type="text" class="form-control" id="password" name="password" value="admin123" readonly>
          </div>
          <div class="form-group">
            <label class="ml-2" for="formGroupExampleInput">Job</label>
            <select name="role_id" id="role_id" class="form-control" required>
                <option value="">Pilih Job</option>

                <?php foreach ($role_id as $r) : ?>
                    <option value="<?= $r['id'] ?>"><?= $r['role_id'] ?></option>
                <?php endforeach; ?>

            </select>
          </div>
        </div>

        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
          <button type="submit" class="btn btn-primary">Simpan</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- MODAL HELP -->

<div class="modal fade help" tabindex="-1" role="dialog" aria-labelledby="helpTitle" aria-hidden="true">
  <div class="modal-dialog modal-xs" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="helpTitle">Panduan</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      
        <div class="modal-body">
          <p>
            Pada halaman ini anda dapat melihat daftar akun yang sudah terdaftar, selain itu anda juga dapat menambahkan akun pada tombol tambah akun lalu mengisi form nya. anda juga dapat mengedit data dan juga menghapus data/akun. <br><br> catatan : <br> 
            <ol>
              <li>
                untuk field password sudah otomatis di isi dengan admin123, pengguna akun yang bersangkutan nantinya dapat merubah password tersebut
              </li>
              <li>
                untuk field job, anda dapat memilih 4 jenis job yaitu <br><b>administrator</b> untuk seorang pemegang akun yang bertugas untuk mengatur konten website (akun anda saat ini adalah sebagai administrator). <br> <b>Member 1</b> untuk seorang pemegang akun yang bertugas untuk mengelola data pendaftar MTs. <br> <b>Member 2</b> untuk seorang pemegang akun yang bertugas untuk mengelola data pendaftar MA. <br> <b>User</b> untuk seorang user biasa atau pendaftar, pada aplikasi ini sudah terdapat dashboard akun User biasa namun isinya belum tersedia. 
              </li>
            </ol>
          </p>
        </div>

        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        </div>
      
    </div>
  </div>
</div>