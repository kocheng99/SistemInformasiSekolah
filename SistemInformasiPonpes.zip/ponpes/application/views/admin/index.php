<!-- Begin Page Content -->
<div class="container-fluid">

  <!-- Page Heading -->
  <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>

  <div class="row">
    <div class="col-lg-10">
      <div class="card shadow mb-4">
        <div class="card-header py-3">
          <h6 class="m-0 font-weight-bold text-primary">Hi, Selamat Datang Kembali <?= $user['name'] ?> !</h6>
        </div>
        <div class="card-body">
          <div class="text-center">
            <img class="img-fluid px-3 px-sm-4 mt-3 mb-4" style="width: 25rem;" src=" <?= base_url('assets/img/undraw_steps_ngvm.svg') ?> ">
          </div>
          <p>
            "Harga diri suatu keberhasilan adalah kerja keras, pengabdian kepada pekerjaan di depan anda dan juga ketekunan yang anda lakukan. Mekipun anda menang atau kalah, tetap berikan yang terbaik dari diri sendiri kepada pekerjaan yang ada di depan anda tersebut." <br><br>-<cite>Vince Lombardi</cite>
          </p>
        </div>
      </div>
    </div>
  </div>
  <hr>
  <h1 class="h5 mb-4 text-gray-800">Total Jumlah Pendaftar / Calon Santri Baru</h1>
  <!-- Content Row -->
  <div class="row">

    <!-- Earnings (Monthly) Card Example -->
    <div class="col-xl-3 col-md-6 mb-4">
      <div class="card border-left-primary shadow h-100 py-2">
        <div class="card-body">
          <div class="row no-gutters align-items-center">
            <div class="col mr-2">
              <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">Pendaftar MTs</div>
              <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $jumlah_mts ?></div>
            </div>
            <div class="col-auto">
              <i class="fas fa-calendar fa-2x text-gray-300"></i>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Earnings (Monthly) Card Example -->
    <div class="col-xl-3 col-md-6 mb-4">
      <div class="card border-left-success shadow h-100 py-2">
        <div class="card-body">
          <div class="row no-gutters align-items-center">
            <div class="col mr-2">
              <div class="text-xs font-weight-bold text-success text-uppercase mb-1">Pendaftar MA</div>
              <div class="h5 mb-0 font-weight-bold text-gray-800"><?= $jumlah_ma ?></div>
            </div>
            <div class="col-auto">
              <i class="fas fa-calendar fa-2x text-gray-300"></i>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->