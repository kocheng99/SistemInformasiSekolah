 <!-- Begin Page Content --> 
<div class="container-fluid"> 

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1> 
 
    <div class="row"> 

        <div class="col-lg-12">
            
            <!-- flashdata untuk message -->
            <div class="flash-data" data-flashdata="<?= $this->session->flashdata('message');?>"></div>

           <a href="#" class="btn btn-primary mb-4" data-toggle="modal" data-target=".addinformasi">Tambah Data</a>
           <div class="card shadow p-3">
            <table class="table table-hover">

                    <thead class="">                     
                        <tr>
                            <th scope="col">No</th>
                            <th scope="col">Judul</th>
                            <th scope="col">Deskripsi</th>
                            <th scope="col">foto</th>
                            <th scope="col">Aksi</th>
                        </tr> 
                    </thead>
                    <tbody>
                        <?php $i = 1; ?>
                        <?php foreach ($informasi as $in) : ?>
                            <tr>
                                <th scope="row"><?= $i; ?></th>
                                <td><?= $in['judul'] ?></td>
                                <td><?= $in['dsc_informasi'] ?></td>
                                <td><img width="50px" src="<?= base_url('assets/img/foto/') . $in['foto']; ?>"></td>
                                <td>
                                    <a href="<?= base_url('konten/editInformasi'); ?>/<?= $in['id']; ?>" type="button" class="btn btn-outline-primary btn-sm">Edit</a>
                                    <a href="<?= base_url('konten/hapusInformasi'); ?>/<?= $in['id']; ?>" type="button" class="tombol-hapus btn btn-outline-danger btn-sm mt-2">Hapus</a>
                                </td>
                            </tr>
                            <?php $i++; ?>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->

<!-- MODAL TAMBAH DATA-->

<div class="modal fade addinformasi" tabindex="-1" role="dialog" aria-labelledby="addinformasiTitle" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="addinformasiTitle">Tambah Data Baru</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <!-- FORM -->
      <?= form_open_multipart('konten/informasi'); ?>
        <div class="modal-body">
          <div class="form-group">
            <label for="judul">Judul</label>
               <input type="text" class="form-control" id="judul" name="judul">
          </div>
          <div class="form-group">
            <label for="deskripsi">Deskripsi</label>
            <textarea class="form-control" id="editor" name="deskripsi" rows="10"></textarea>
          </div>
          <div class="form-group">
            <label for="foto">Upload foto</label>
            <input type="file" class="form-control" id="foto" name="foto">
          </div>

        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
          <button type="submit" class="btn btn-primary">Simpan</button>
        </div>
      </form>
      <!-- AKHIR FORM -->
    </div>
  </div>
</div>
