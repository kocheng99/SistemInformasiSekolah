<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading --> 
    <h1 class="ml-2 h3 mb-4 text-gray-800"><?= $title; ?></h1>
    
    <div class="row">
        <div class="col-lg-12">
                
            <div class="card shadow"> 
                <div class="card-body border-bottom-info">
                <!-- A W A L   F O R M -->
                <?= form_open_multipart(); ?>
                    <input type="hidden" name="id" value="<?= $idInformasi['id']; ?>">

                    <div class="form-group row">
                        <label for="judul" class="col-sm-2 col-form-label">Judul</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="judul" name="judul" value="<?= $idInformasi['judul'];?>">
                            <?= form_error('judul', '<small class="text-danger pl-3">', '</small>') ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="name" class="col-sm-2 col-form-label">Deskripsi</label>
                        <div class="col-sm-10">
                            <textarea class="form-control" id="editor" name="deskripsi" rows="6"><?= $idInformasi['dsc_informasi'];?></textarea>
                            <?= form_error('deskripsi', '<small class="text-danger pl-3">', '</small>') ?>
                        </div>
                    </div>
                    <div class="row">  

                        <div class="col-sm-2">Foto</div>
                        <div class="col-sm-10">

                            <div class="row">
                                <div class="col-sm-3">
                                    <img src="<?= base_url('assets/img/foto/') . $idInformasi['foto']; ?>" class="img-thumbnail">
                                </div>
                                <div class="col-sm-9">
                                    <div class="form-group">                                       
                                        <input type="file" class="form-control" id="foto" name="foto">
                                    </div>
                                    <!-- <div class="custom-file">
                                        <input type="file" class="custom-file-input" id="foto" name="foto">
                                        <label class="custom-file-label" for="foto">Choose file</label>
                                    </div> -->
                                </div>
                            </div>

                        </div>

                    </div>
                    <!-- B U T T O N -->
                    <div class="form-group row justify-content-end pt-3">
                        <div class="col-sm-10">
                            <button type="submit" class="btn btn-primary">Simpan</button>
                        </div>
                    </div>

                </form>
                <!-- A K H I R   F O R M -->
                </div>
            </div>

        </div>
    </div>  


</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->
