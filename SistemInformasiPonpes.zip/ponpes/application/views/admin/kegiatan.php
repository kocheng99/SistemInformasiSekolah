 <!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>
    
    <div class="row"> 
 
        <div class="col-lg-12"> 
            
            <!-- flashdata untuk message -->
            <div class="flash-data" data-flashdata="<?= $this->session->flashdata('message');?>"></div>

           <a href="#" class="btn btn-primary mb-4" data-toggle="modal" data-target=".addData">Tambah Data</a>
           <div class="card shadow p-3">
            <table class="table table-hover">

                    <thead class="text-center">                     
                        <tr>
                            <th scope="col">No</th>
                            <th scope="col">Judul</th>
                            <th scope="col">Deskripsi</th>
                            <th scope="col">Aksi</th>
                        </tr> 
                    </thead>
                    <tbody>
                        <?php $i = 1; ?>
                        <?php foreach ($kegiatan as $keg) : ?>
                            <tr>
                                <th scope="row"><?= $i; ?></th>
                                <td><?= $keg['judul'] ?></td>
                                <td><?= $keg['dsc_kegiatan'] ?></td>
                                <td>
                                    <a href="<?= base_url('konten/editKegiatan'); ?>/<?= $keg['id']; ?>" type="button" class="btn btn-outline-primary btn-sm">Edit</a>
                                    <a href="<?= base_url('konten/hapusKegiatan'); ?>/<?= $keg['id']; ?>" type="button" class="tombol-hapus btn btn-outline-danger btn-sm mt-2">Hapus</a>
                                </td>
                            </tr>
                            <?php $i++; ?>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->

<!-- MODAL TAMBAH DATA-->

<div class="modal fade addData" tabindex="-1" role="dialog" aria-labelledby="addDataTitle" aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="addDataTitle">Tambah Data Baru</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="<?= base_url('konten/kegiatan')?>" method="post">
        <div class="modal-body">
      
          <div class="form-group">
            <label for="judul">Judul Deskripsi</label>
               <input type="text" class="form-control" id="judul" name="judul">
               <?= form_error('judul', '<small class="text-danger pl-3">', '</small>') ?>
          </div>
          <div class="form-group">
            <label for="deskripsi">Deskripsi</label>
            <textarea class="form-control" id="editor" name="deskripsi" rows="10"></textarea>
            <?= form_error('deskripsi', '<small class="text-danger pl-3">', '</small>') ?>
         </div>

        </div>

        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
          <button type="submit" class="btn btn-primary">Simpan</button>
        </div>
      </form>
    </div>
  </div>
</div>
