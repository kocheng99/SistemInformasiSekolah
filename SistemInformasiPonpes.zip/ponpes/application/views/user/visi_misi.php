<!--Begin Page Content -->
<div class="container mt-5">

<div class="card border-top-0 border-left-0 border-right-3 border-bottom-3 mb-5">
    <div class="row no-gutters shadow p-4 bg-white">
        <div class="col-md-12">
        <div class="card-body">
            <h4 class="card-title">VISI & MISI PONDOK PESANTREN AL-MU’MINIEN</h4>
            <div class="row bg-primary mx-auto col-md-12 mb-4">
                <div style="height: 3px;">
                        <hr>
                </div> 
            </div>
 
        <div class="row row-cols-1 row-cols-md-2">

            <div class="mx-auto text-center col mb-2 py-2">
                <div class="card">
                    <a href="<?= base_url('assets/img/logo-pesantren.jpg');?>" target="_blank">
                        <img src="<?= base_url('assets/img/logo-pesantren.jpg');?>" class="card-img-top img-thumbnail" alt="Lights">
                    </a>
                </div>
            </div>

        </div>

        <div>
            <h5 class="mx-auto mt-5 text-center">VISI PONDOK PESANTREN AL-MU’MINIEN</h5>
        </div>

        <p class="mt-3">Demi mencapai cita-cita mulia pendirian pesantren, maka Pondok Pesantren Al-Mu’minien Lohbener menetapkan visi lembaga sebagai berikut:</p>

        <p class="mt-3">Bekerja ikhlas dalam mendidik dan mengantar santri menjadi insan trampil dan mandiri yang:
            <ol>
                <li>Beriman dan berakhlak mulia</li>
                <li>Berilmu, berkembang dan maju</li>
                <li>Berjasa bagi kaumnya.</li>
            </ol>
        </p>

        <p class="mt-3">Visi Pondok Pesantren Al-Mu’minien Lohbener diatas mempunyai cakupan makna sebagai berikut:
            <ol>
                <li>Semua pendidik di Pondok Pesantren Al-Mu’minien Lohbener (di semua jajaran) bekerja tanpa pamrih kepada manusia dan lingkungan – kami hanya berpamrih kepada Allah Sang Maha Pemilik Ilmu.</li>

                <li>Kami bekerja keras dan penuh kasih sayang dalam merubah santri dari tidak tahu dalam hal pengetahuan, keterampilan, emosional dan spiritual menjadi tahu akan hal tersebut.  Kami juga membina, membimbing dan mengarahkan santri dalam proses pencapaian tujuan pembelajaran.</li>

                <li>Kami ingin dengan kesungguhan kami tersebut, kami akan mampu membuat santri menjadi cakap dan mampu mengolah dan mengelola potensi yang ada dalam diri mereka.</li>

                <li>Dengan kesungguhan usaha, kami akan melahirkan santri yang hanya bergantung pada diri sendiri, meyakini hadirnya Allah dalam keseharian mereka dengan cara menjalankan apa yang diperintahkanNya dan dengan ikhlas menjauhi apa yang dilarangNya.  Kami membimbing mereka menjadi rendah hati, senang berbagi ilmu, tenaga, materi dll, menghargai orang lain serta peduli pada sesama makhluk – untuk merealisasikan cita-cita rahmatan lil ‘alamin – kasih bagi alam semesta.</li>
                
                <li>Para santri kami didik untuk memiliki pengetahuan dan wawasan keagamaan dan keilmuan yang sesuai dengan tingkat pendidikan yang mereka laksanakan di pesantren ini.</li>

                <li>Dengan bimbingan kami, mereka tidak akan cepat puas dengan apa yang didapat dan terus menerus mencari pengetahuan dan ilmu baru baik dalam pesantren maupun di luar pesantren.</li>

                <li>Selama dalam bimbingan kami, kami akan pastikan bahwa dimanapun mereka berada, mereka akan menciptakan nilai-nilai kebaikan hati.</li>

            </ol>
        </p>

        <div>
            <h5 class="mx-auto mt-5 text-center">MISI PONDOK PESANTREN AL-MU’MINIEN</h5>
        </div>

        <p class="mt-3">Untuk mencapai visi dan mengingat hal-hal penting yang menjadi cakupan makna dari visi tersebut, maka kami para pendidik di Pondok Pesantren Al-Mu’minien Lohbener:
            <ol>
                <li>Secara terus menerus, pendidik di semua tingkatan di pesantren, memberikan teladan perilaku iman, akhlak mulia, hasrat mengembangkan diri dan menanamkan kebaikan bagi semua santri dan masyarakat.</li>

                <li>Tidak ada satupun santri yang lepas dari arahan dan bimbingan tentang pengembangan keilmuan dan spiritualitas yang dilakukan dengan ikhlas dan berkesinambungan dan mendorong serta menghargai kreatifitas santri untuk memastikan keberagaman cara mencapai tujuan yang baik.</li>

                <li>Menyediakan dan menjaga fasilitas peningkatan ketrampilan yang berhubungan dengan pengembangan potensi dan kompetensi santri</li>

                <li>Membangun kerjasama dengan instansi atau lembaga lain yang membawa kebaikan dan bertambahnya ilmu bagi pesantren dan para santri (misalnya: DEPAG, DIKNAS, Lembaga Pelatihan, LSM, dll)</li>

                <li>Memastikan peningkatan etos kerja dan kompetensi bagi SDM di pesantren dengan mengandalkan pada kepemimpinan yang kuat dan bijaksana di semua marhalah (tingkatan)</li>

                <li>Bersama dengan santri melaksanakan program kerja sosial yang sesuai dengan kebutuhan masyarakat sekitar pesantren.</li>

                <li>Memaksimalkan pendidikan formal DAN non formal (extra curricular) dengan kajian-kajian beragam disiplin ilmu dan ketrampilan.</li>
            </ol>
        </p>

        

    </div>
    </div>
    </div>
    </div>
    </div>
</div>

</div>
<!-- End of Main Content