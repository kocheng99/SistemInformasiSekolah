<!-- Begin Page Content -->

<!-- AWAL CONTAINER -->
    <div class="container mt-5 ">

    <div class="row"> 
        <div class="mt-4">
            <h3>What is Lorem Ipsum?</h3>
        </div>
    </div>

    <div class="row bg-primary col-md-9 ">
        <div style="height: 3px;">
            <hr>
        </div>
    </div>
    
    <div class="row mt-4 mb-5">
        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. 
            Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, 
            when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, 
            but also the leap into electronic typesetting, remaining essentially unchanged. 
            It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, 
            and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum.</p>
    </div>

    <div class="row mb-5">
        <div class="mx-auto">
            <h2 class="text-uppercase">form pendaftaran al-mu'minien</h2>
        </div>
    </div>

    <div class="my-5">
        <div class="col ml-5">
            <div class="ml-5">
                <div class="ml-5">
                    <div class="col-4 btn btn-primary btn-lg ml-5 py-4 mb-5" style="border-radius: 25px;">
                        <a href="<?= base_url(); ?>/smp" role="button" class="text-white text-uppercase">smp</a>
                    </div>
                    <div class="col-4 btn btn-primary btn-lg ml-5 py-4 mb-5" style="border-radius: 25px;">
                        <a href="<?= base_url(); ?>/sma" role="button" class="text-white text-uppercase" >sma</a>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>    
<!-- AKHIR CONTAINER -->

</div>
<!-- End of Main Content -->
