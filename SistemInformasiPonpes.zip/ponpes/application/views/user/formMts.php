<!-- Begin Page Content -->
  
<!-- AWAL CONTAINER -->  
<div class="container mt-5"> 

<div class="card border-top-0 border-left-0 border-right-3 border-bottom-3 mb-5">
    <div class="row no-gutters shadow p-4 bg-white">
        <div class="col-md-12">
        <div class="card-body"> 
            <h4 class="card-title"><?= $title;?></h4>
            <div class="row bg-primary mx-auto col-md-12 mb-4">
                <div style="height: 3px;">
                        <hr>
                </div>
            </div> 

            <div class="row">
                <div class="col-md-9 mx-auto mt-4">
                    <?= form_open_multipart('Pendaftaran/tambah_mts'); ?>
                      <div class="form-group">
                        <label for="nama">Nama Lengkap</label>
                        <input type="text" class="form-control" id="nama" name="nama" aria-describedby="emailHelp" required>
                        <?= form_error('name', '<small class="text-danger pl-3">', '</small>') ?>
                      </div>
                      <div class="form-group">
                        <label for="ttl">Tempat, Tanggal Lahir</label>
                        <input type="text" class="form-control" id="ttl" name="ttl" required>
                        <?= form_error('ttl', '<small class="text-danger pl-3">', '</small>') ?>
                      </div>
                      <div class="form-group">
                        <label for="jenis_kelamin">Jenis Kelamin</label>
                        <input type="text" class="form-control" id="jenis_kelamin" name="jenis_kelamin" required>
                        <?= form_error('jenis_kelamin', '<small class="text-danger pl-3">', '</small>') ?>
                      </div>
                      <div class="form-group">
                        <label for="nisn">NISN</label>
                        <input type="number" class="form-control" id="nisn" name="nisn" required>
                        <?= form_error('nisn', '<small class="text-danger pl-3">', '</small>') ?>
                      </div>
                      <div class="form-group">
                        <label for="nik">NIK</label>
                        <input type="number" class="form-control" id="nik" name="nik" required>
                        <?= form_error('nik', '<small class="text-danger pl-3">', '</small>') ?>
                      </div>
                      <div class="form-group">
                        <label for="anak">Anak Ke</label>
                        <input type="number" class="form-control" id="anak" name="anak" required>
                        <?= form_error('anak', '<small class="text-danger pl-3">', '</small>') ?>
                      </div>
                      <div class="form-group">
                        <label for="status_anak">Status Anak</label>
                        <input type="text" class="form-control" id="status_anak" name="status_anak" required>
                        <?= form_error('status_anak', '<small class="text-danger pl-3">', '</small>') ?>
                      </div>
                      <div class="form-group">
                        <label for="alamat">Alamat Lengkap</label>
                        <textarea class="form-control" id="alamat" name="alamat" rows="3"></textarea>
                        <?= form_error('alamat', '<small class="text-danger pl-3">', '</small>') ?>
                      </div>
                      <div class="form-group">
                        <label for="status_santri">Status Calon Santri</label>
                        <select class="form-control" id="status_santri" name="status_santri">
                          <option>Baru</option>
                          <option>Pindahan</option>
                        </select>
                        <?= form_error('status_santri', '<small class="text-danger pl-3">', '</small>') ?>
                      </div>
                      <div class="form-group">
                        <label for="sekolah_asal">Sekolah Asal (Lulusan)</label>
                        <select class="form-control" id="sekolah_asal" name="sekolah_asal">
                          <option>SD</option>
                          <option>MI</option>
                        </select>
                        <?= form_error('sekolah_asal', '<small class="text-danger pl-3">', '</small>') ?>
                      </div>
                      <div class="form-group">
                        <label for="nama_sekolah">Nama Sekolah Asal</label>
                        <input type="text" class="form-control" id="nama_sekolah" name="nama_sekolah" required>
                        <?= form_error('nama_sekolah', '<small class="text-danger pl-3">', '</small>') ?>
                      </div>
                      <div class="form-group">
                        <label for="alamat_sekolah">Alamat Sekolah Asal</label>
                        <input type="text" class="form-control" id="alamat_sekolah" name="alamat_sekolah" required>
                        <?= form_error('alamat_sekolah', '<small class="text-danger pl-3">', '</small>') ?>
                      </div>
                      <div class="form-group">
                        <label for="kk">No. KK (Kartu Keluarga)</label>
                        <input type="number" class="form-control" id="kk" name="kk" required>
                        <?= form_error('kk', '<small class="text-danger pl-3">', '</small>') ?>
                      </div>
                      <div class="form-group">
                        <label for="nama_ayah">Nama Ayah</label>
                        <input type="text" class="form-control" id="nama_ayah" name="nama_ayah" required>
                        <?= form_error('nama_ayah', '<small class="text-danger pl-3">', '</small>') ?>
                      </div>
                      <div class="form-group">
                        <label for="nik_ayah">NIK Ayah</label>
                        <input type="number" class="form-control" id="nik_ayah" name="nik_ayah" required>
                        <?= form_error('nik_ayah', '<small class="text-danger pl-3">', '</small>') ?>
                      </div>
                      <div class="form-group">
                        <label for="pekerjaan_ayah">Pekerjaan Ayah</label>
                        <input type="text" class="form-control" id="pekerjaan_ayah" name="pekerjaan_ayah" required>
                        <?= form_error('pekerjaan_ayah', '<small class="text-danger pl-3">', '</small>') ?>
                      </div>
                      <div class="form-group">
                        <label for="nama_ibu">Nama Ibu</label>
                        <input type="text" class="form-control" id="nama_ibu" name="nama_ibu" required>
                        <?= form_error('nama_ibu', '<small class="text-danger pl-3">', '</small>') ?>
                      </div>
                      <div class="form-group">
                        <label for="nik_ibu">NIK Ibu</label>
                        <input type="number" class="form-control" id="nik_ibu" name="nik_ibu" required>
                        <?= form_error('nik_ibu', '<small class="text-danger pl-3">', '</small>') ?>
                      </div>
                      <div class="form-group">
                        <label for="pekerjaan_ibu">Pekerjaan Ibu</label>
                        <input type="text" class="form-control" id="pekerjaan_ibu" name="pekerjaan_ibu" required>
                        <?= form_error('pekerjaan_ibu', '<small class="text-danger pl-3">', '</small>') ?>
                      </div>
                      <div class="form-group">
                        <label for="nomor_hp">Nomor HP / WhatsApp</label>
                        <input type="number" class="form-control" id="nomor_hp" name="nomor_hp" required>
                        <?= form_error('nomor_hp', '<small class="text-danger pl-3">', '</small>') ?>
                      </div>
                      <div class="form-group mt-5">
                        <label for="upload_foto">Upload foto <br><small>*format yang didukung : jpg/jpeg/png</small><br><small>*ukuran file max : 5 MB</small></label>

                        <input type="file" class="form-control" id="upload_foto" name="upload_foto" required>
                        <?= form_error('upload_foto', '<small class="text-danger pl-3">', '</small>') ?>
                      </div>
                      <div class="form-group">
                        <label for="upload_akte">Upload Akte Kelahiran<br><small>*format yang didukung : doc/docx/pdf</small></label>
                        <input type="file" class="form-control" id="upload_akte" name="upload_akte" required>
                        <?= form_error('upload_akte', '<small class="text-danger pl-3">', '</small>') ?>
                      </div>
                      <div class="form-group">
                        <label for="upload_kk">Upload Kartu Keluarga<br><small>*format yang didukung : doc/docx/pdf</small></label>
                        <input type="file" class="form-control" id="upload_kk" name="upload_kk" required>
                        <?= form_error('upload_kk', '<small class="text-danger pl-3">', '</small>') ?>
                      </div>
                      <button type="submit" class="btn btn-primary mt-4">Submit</button>
                    </form>
                </div>
            </div>

        

        </div>
        </div>
    </div>
</div>
</div>
<!-- AKHIR CONTAINER -->
</div>
<!-- End of Main Content -->
