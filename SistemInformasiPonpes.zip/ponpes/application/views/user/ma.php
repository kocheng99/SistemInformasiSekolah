<!-- Begin Page Content --> 

<!-- AWAL CONTAINER --> 
    <div class="container mt-5">
    <div class="flash-data" data-flashdata="<?= $this->session->flashdata('message');?>"></div>
<div class="card border-top-0 border-left-0 border-right-3 border-bottom-3 mb-5">
    <div class="row no-gutters shadow p-4 bg-white">
        <div class="col-md-12">
        <div class="card-body">
            <h4 class="card-title">Penerimaan Santri Baru MA</h4>
            <div class="row bg-primary mx-auto col-md-12 mb-4">
                <div style="height: 3px;">
                        <hr>
                </div> 
            </div>
            
            <?php foreach ($ma as $m) : ?>
                <p><?= $m['dsc_ma'];?></p>
            <?php endforeach ?>

        <p>Silahkan klik link dibawah ini untuk mengisi formulir pendaftaran MA:</p>

        <div class="mx-auto mb-5">
            <div class="d-flex justify-content-start">
                <div class="btn btn-primary btn-lg" style="border-radius: 25px;">
                    <a href="<?= base_url('Pendaftaran/formMa');?>" role="button" class="text-white text-uppercase">formulir PSB MA</a>
                </div>
            </div>
        </div>


    </div>
    </div>
    </div>
    </div>
    </div>
</div>
<!-- AKHIR CONTAINER -->

</div>
<!-- End of Main Content -->
