<!-- Begin Page Content -->
<div class="container-fluid"> 
 
    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>
 
    <div>
        <?php foreach ($konten as $k) : ?>
            <div class="card shadow mb-3 p-3">
                <h5><?= $k['judul'];  ?></h5>
                <p><?= substr(strip_tags($k['dsc_sejarah']), 0, 50) ?>...</p>
            </div>
            
        <?php endforeach; ?>
        
    </div>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->
