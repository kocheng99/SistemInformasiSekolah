<!--Begin Page Content --> 
<div class="container mt-5"> 

<?php foreach ($informasi as $in) : ?>
    <div class="card border-top-0 border-left-0 border-right-3 border-bottom-3 mb-5">
        <div class="row no-gutters shadow p-4 bg-white">
            <div class="col-md-12">
                <div class="card-body">                  
                        <h4 class="card-title"><?= $in['judul']?></h4>
                        <div class="row bg-primary mx-auto col-md-12 mb-4">
                            <div style="height: 3px;">
                                    <hr>
                            </div>
                        </div>
                        <img width="250px" src="<?= base_url('assets/img/foto/')?>/<?= $in['foto']?>" alt="">
                        <div>
                            <?= $in['dsc_informasi']?>
                        </div>
                        
                                                           
                </div>              
            </div>
        </div>
    </div>
<?php endforeach ?>    
</div>
</div>

</div>
<!-- End of Main Content
