<!-- Begin Page Content -->
<div class="container mt-5 ">

    <div class="row">
        <div class="mt-5">
            <h3><?= $beranda['judul'] ?></h3>
        </div>
    </div>

    <div class="row bg-primary col-md-9 ">
        <div style="height: 3px;">
            <hr>
        </div>
    </div>

    <div class="row mt-4">
        <?= $beranda['dsc_beranda'] ?>
    </div>

    <div class="card-deck mt-5 mb-5">
        <div class="card">
            <div class="card-body">
                <h5 class="card-title "><?= $first_card['judul'] ?></h5>
                <div class="row bg-primary mx-0 col-md-11">
                    <div style="height: 3px;">
                        <hr>
                    </div>
                </div>
                <p class="card-text mt-3">
                    <?= $first_card['dsc_beranda'] ?>
            </div>
        </div>

        <div class="card">
            <div class="card-body">
                <h5 class="card-title "><?= $second_card['judul'] ?></h5>
                <div class="row bg-primary mx-0 col-md-11">
                    <div style="height: 3px;">
                        <hr>
                    </div>
                </div>
                <p class="card-text mt-3">Membangun jaringan kerjasama dengan instansi atau lembaga lain yang membawa kebaikan dan bertambahnya ilmu bagi pesantren dan para santri.</p>
            </div>
        </div>

        <div class="card">
            <div class="card-body">
                <h5 class="card-title ">No. 3</h5>
                <div class="row bg-primary mx-0 col-md-11">
                    <div style="height: 3px;">
                        <hr>
                    </div>
                </div>
                <p class="card-text mt-3">Menyediakan dan menjaga fasilitas peningkatan ketrampilan yang berhubungan dengan pengembangan potensi dan kompetensi santri.</p>
            </div>
        </div>

    </div>

    <div class="card-deck mx-5 mt-5 mb-5">

        <div class="card mx-5 ">
            <div class="card-body">
                <h5 class="card-title ">No. 4</h5>
                <div class="row bg-primary mx-0 col-md-11">
                    <div style="height: 3px;">
                        <hr>
                    </div>
                </div>
                <p class="card-text mt-3">
                    Mengintensifkan program-program kajian lintas disiplin keilmuan (terutama khazanah keislaman klasik), baik untuk para santri maupun untuk para tenaga pengajar.
            </div>
        </div>

        <div class="card mx-5">
            <div class="card-body">
                <h5 class="card-title">No. 5</h5>
                <div class="row bg-primary mx-0 col-md-11">
                    <div style="height: 3px;">
                        <hr>
                    </div>
                </div>
                <p class="card-text mt-3">
                    Melaksanakan program kerja sosial yang sesuai dengan kebutuhan masyarakat sekitar pesantren.
            </div>
        </div>
    </div>


    <div class="row">
        <div class="mx-auto mt-5">
            <h2>Informasi</h2>
        </div>
    </div>

    <div class="row bg-primary mx-auto col-md-8 mb-5">
        <div style="height: 3px;">
            <hr>
        </div>
    </div>

    <div class="row">
        <?php foreach ($informasi as $in) : ?>
            <div class="card mx-auto mb-3" style="width: 23rem;">
                <img width="300px" height="200px" src="<?= base_url('assets/img/foto/') ?>/<?= $in['foto'] ?>" alt="" class="card-img-top mx-auto d-block rounded">
                <div class="card-body">
                    <h5 class="card-title"><?= $in['judul'] ?></h5>
                    <p><small><?= date('d-m-Y', strtotime($in['tgl_dibuat'])); ?></small></p>
                    <p class="card-text"><?= substr(strip_tags($in['dsc_informasi']), 0, 150) ?>...</p>

                    <a href="<?= base_url('user/informasi'); ?>"><button type="button" class="btn btn-info">
                            Read More
                        </button></a>
                </div>
            </div>
        <?php endforeach ?>
    </div>


</div>

</div>
<!-- End of Main Content -->