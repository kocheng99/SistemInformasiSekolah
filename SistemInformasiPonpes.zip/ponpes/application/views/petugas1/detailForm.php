<!-- Begin Page Content -->
<div class="container-fluid"> 
 
    <!-- Page Heading -->
    <h1 class="h3 mb-4 text-gray-800"><?= $title; ?></h1>
    <div class="row">
        <div class="col-sm-2">
            <a href="<?= base_url('petugas1/pendaftaran_mts');?>">
                <button class="btn btn-outline-primary mb-4"><i class="fas fa-chevron-circle-left">&nbsp;</i>KEMBALI</button>
            </a>
        </div>
    </div>
        <div class="row">
            <div class="col-lg-9">
                <div class="card p-3 shadow">
                    
                    <table class="table table-hover">
                        <tr>
                            <th>Nama</th>
                            <td><?= $detail['nama']?></td>
                        </tr>
                        <tr>
                            <th>Tempat, Tanggal lahir</th>
                            <td><?= $detail['ttl']?></td>
                        </tr>
                        <tr>
                            <th>Kenis kelamin</th>
                            <td><?= $detail['jenis_kelamin']?></td>
                        </tr>
                        <tr>
                            <th>NISN</th>
                            <td><?= $detail['nisn']?></td>
                        </tr>
                        <tr>
                            <th>NIK</th>
                            <td><?= $detail['nik']?></td>
                        </tr>
                        <tr>
                            <th>Anak ke-</th>
                            <td><?= $detail['anak']?></td>
                        </tr>
                        <tr>
                            <th>Status anak</th>
                            <td><?= $detail['status_anak']?></td>
                        </tr>
                        <tr>
                            <th>Alamat</th>
                            <td><?= $detail['alamat']?></td>
                        </tr>
                        <tr>
                            <th>Status santri</th>
                            <td><?= $detail['status_santri']?></td>
                        </tr>
                        <tr>
                            <th>Asal sekolah</th>
                            <td><?= $detail['sekolah_asal']?></td>
                        </tr>
                        <tr>
                            <th>Nama sekolah</th>
                            <td><?= $detail['nama_sekolah']?></td>
                        </tr>
                        <tr>
                            <th>Alamat sekolah</th>
                            <td><?= $detail['alamat_sekolah']?></td>
                        </tr>
                        <tr>
                            <th>Nomor KK</th>
                            <td><?= $detail['kk']?></td>
                        </tr>
                        <tr>
                            <th>Nama ayah</th>
                            <td><?= $detail['nama_ayah']?></td>
                        </tr>
                        <tr>
                            <th>NIK ayah</th>
                            <td><?= $detail['nik_ayah']?></td>
                        </tr>
                        <tr>
                            <th>Pekerjaan ayah</th>
                            <td><?= $detail['pekerjaan_ayah']?></td>
                        </tr>
                        <tr>
                            <th>Nama ibu</th>
                            <td><?= $detail['nama_ibu']?></td>
                        </tr>
                        <tr>
                            <th>NIK ibu</th>
                            <td><?= $detail['nik_ibu']?></td>
                        </tr>
                        <tr>
                            <th>Pekerjaan ibu</th>
                            <td><?= $detail['pekerjaan_ibu']?></td>
                        </tr>
                        <tr>
                            <th>Nomor HP/Whatsapp</th>
                            <td><?= $detail['nomor_hp']?></td>
                        </tr>
                        <tr>
                            <th>Foto</th>
                            <td><img width="150px" src="<?= base_url('assets/file_upload/mts/foto/') . $detail['upload_foto']; ?>"></td>
                        </tr>

                    </table>

                </div>
            </div>
        </div>

</div>
<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->