<!-- Footer -->
<footer class="sticky-footer bg-white"> 
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Copyright &copy; Ponpes Modern Al-Mu'minien <?= date('Y', $user['date_create']); ?></span>
        </div>
    </div> 
</footer>  
<!-- End of Footer --> 

</div>
<!-- End of Content Wrapper -->
 
</div>
<!-- End of Page Wrapper --> 

<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>


<!-- Bootstrap core JavaScript-->
<script src="<?= base_url('assets/'); ?>vendor/jquery/jquery.min.js"></script>
<script src="<?= base_url('assets/'); ?>vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

<!-- Core plugin JavaScript-->
<script src="<?= base_url('assets/'); ?>vendor/jquery-easing/jquery.easing.min.js"></script>

<!-- Custom scripts for all pages-->
<script src="<?= base_url('assets/'); ?>js/sb-admin-2.min.js"></script>

<!-- sweet alert -->
<script src="<?= base_url('assets/'); ?>SweetAlert/sweetalert2.all.min.js"></script>
<script src="<?= base_url('assets/'); ?>custom/js/myscript.js"></script>


<!-- plugin datatables -->
<script src="<?= base_url('assets/'); ?>vendor/datatables/jquery.dataTables.min.js"></script>
<script src="<?= base_url('assets/'); ?>vendor/datatables/dataTables.bootstrap4.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.2/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.print.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.colVis.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.6.2/js/buttons.html5.min.js"></script>
<!-- data tables -->
<script>
	$(document).ready(function() {
		$('#table1').DataTable(  {
	        dom: 'Bfrtip',
	        buttons: [
	            {
	                extend: 'print',
	                exportOptions: {
	                    columns: ':visible'
	                }
	            },
	            {
	                extend: 'excelHtml5',
	                exportOptions: {
	                    columns: ':visible'
	                }
	            },            
	            'colvis'
	        ],
	        columnDefs: [ {
	            targets: 0,
	            visible: false
	        } ]	
    	});
	});
</script>

<!-- ckeditor -->
 <script>
 	CKEDITOR.replace( 'editor' );
 </script>
</body>

</html>