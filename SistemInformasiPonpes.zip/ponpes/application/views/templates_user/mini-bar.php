<div class="container mt-4">
    <div class="row mb-1">
            <div class="ml-5 w-75">
                <h6 class="text-uppercase"><?= $title; ?></h6>
            </div>

            <div class="ml-5">
                <h6>Home / <?= $title; ?></h6> 
            </div>
        </div>

        <div class="row bg-primary col-mx-auto ">
            <div style="height: 3px;">
                <hr>
            </div>
        </div>
    </div> 
</div>