	<div class="row bg-info mx-auto mb-1">
	  <div style="height: 30px;">
	    <hr>
	  </div>
	</div>

	<div class="row bg-info mx-auto">
	  <div style="height: 100px;">
	    <hr>
	  </div>
	  <div class="mx-auto mt-5 mb-5 text-light">
	    <h2 style="text-align: center;">Alamat</h2>
	    <p>Jl. Lohbener, Lohbener, Kec. Indramayu, Kabupaten Indramayu, Jawa Barat 45252</p>
	  </div>
	</div>

	<!-- Optional JavaScript -->
	<!-- jQuery first, then Popper.js, then Bootstrap JS -->

	<script src="<?= base_url('assets/'); ?>bootstrap/js/Jquery.js"></script>
	<script src="<?= base_url('assets/'); ?>bootstrap/js/Popper.js"></script>
	<script src="<?= base_url('assets/'); ?>bootstrap/js/bootstrap.min.js"></script>

	<script src="<?= base_url('assets/'); ?>SweetAlert/sweetalert2.all.min.js"></script>
	<script src="<?= base_url('assets/'); ?>custom/js/myscript.js"></script>

	<!-- typed.js -->
	<script src="https://cdnjs.cloudflare.com/ajax/libs/typed.js/2.0.8/typed.min.js"></script>
	<!-- typed configuration -->
	<script type="text/javascript">
	  var typed = new Typed("#typed", {
	    strings: ["Pondok Pesantren Modern", "Al-Mu'Minien", "Lohbener", "Indramayu"],
	    typeSpeed: 110,
	    startDelay: 500,
	    loop: true
	  });
	</script>
	</body>

	</html>