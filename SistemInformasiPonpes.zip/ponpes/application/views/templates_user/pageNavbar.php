<!doctype html>
<html lang="en"> 
  <head>
    <!-- Required meta tags --> 
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="<?= base_url('assets/'); ?>bootstrap/css/bootstrap.min.css"> 

    <!-- custom css -->
    <link rel="stylesheet" href=" <?= base_url('assets/custom/css/customPageNavbar.css');?> ">
    
    <title><?php echo $title; ?></title>
  </head>
  <body>

<div class="mynav">
      <nav class="navbar navbar-expand-lg navbar-dark bg-info">
    <div class="container">
    <img class="rounded-circle" style="max-width: 70px;"src="<?= base_url('assets/img/logo-pesantren.jpg'); ?>" alt="logo">
    <a class="navbar-brand ml-3" href="<?= base_url('user');?>">AL-MU'MINIEN<br>INDRAMAYU</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span> 
    </button> 

    <div class="collapse navbar-collapse pl-5 ml-5" id="navbarSupportedContent"> 
      <ul class="navbar-nav nav-fill pl-4 ml-5">
        
        <?php foreach ($dropdown as $d) : ?> 
          <!-- cek navbar nya bukan navbar yang punya sub navbar -->
            <?php if ($d['navigasi_bar_id'] != $d['sub_navbar_id']) : ?>
              <li class="nav-item active">
                <a class="nav-link" href="<?= base_url($d['link']);?>"><?= $d['navbar']?></a>
              </li>
            
            <!-- tampilkan menu yang punya sub navbar -->
            <?php else : ?>
            <li class="nav-item dropdown active">
              <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <?= $d['navbar']?>
              </a>
              <div class="dropdown-menu" aria-labelledby="navbarDropdown">

                <?php foreach ($dropdown_item as $di) : ?>
                  <!-- cek navbar nya bukan navbar yang punya sub navbar -->
                    <?php if ($d['navigasi_bar_id'] == $di['navbar_id']) : ?>
                    <!-- <li class="nav-item active"> -->
                      <a class="dropdown-item" href="<?= base_url($di['url']);?>"><?= $di['nama_sub']?></a>
                    <!-- </li> -->

                    <!-- tampilkan menu yang punya sub navbar -->
                    <?php endif; ?>
                <?php endforeach ?>
               
              </div>
            </li>
            <?php endif ?>

        <?php endforeach ?>
        
        </ul>     
    </div>
    </div>
  </nav>
    </div>
